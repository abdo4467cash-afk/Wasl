package com.wasl.chat.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wasl.chat.model.ConnectionState
import com.wasl.chat.model.PeerDevice
import com.wasl.chat.model.TransportType
import com.wasl.chat.network.LanDiscoveryAndTransportManager
import com.wasl.chat.ui.components.ConnectionStatePill
import com.wasl.chat.ui.components.TransportModeSelector
import com.wasl.chat.ui.components.WaslPrimaryButton
import com.wasl.chat.ui.components.WaslSecondaryButton
import com.wasl.chat.ui.theme.WaslColors

@Composable
fun ConnectionManagementScreen(
    selectedTransport: TransportType,
    connectionState: ConnectionState,
    localIpAndPort: String,
    activePeer: PeerDevice?,
    onSelectTransport: (TransportType) -> Unit,
    onConnectDirectByIp: (ip: String, port: String) -> Unit,
    onReconnectCurrentTransport: () -> Unit,
    onDisconnectAll: () -> Unit,
    onNavigateBack: () -> Unit
) {
    var manualIp by rememberSaveable { mutableStateOf("") }
    var manualPort by rememberSaveable { mutableStateOf(LanDiscoveryAndTransportManager.DEFAULT_PORT.toString()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WaslColors.WarmIvoryBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            WaslSecondaryButton(text = "→ رجوع", onClick = onNavigateBack)
            Text(
                text = "إدارة الاتصال المحلي",
                style = MaterialTheme.typography.headlineMedium
            )
        }

        // Current Live Session Status Card
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WaslColors.ElevatedCardSurface,
            border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "الحالة الحية للاتصال",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(10.dp))
                ConnectionStatePill(
                    connectionState = connectionState,
                    transportType = selectedTransport
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "عنوان الشبكة المحلية لهذا الجهاز: $localIpAndPort",
                    style = MaterialTheme.typography.bodyMedium
                )
                if (activePeer != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "الطرف المرتبط حاليًا: ${activePeer.nickname} (${activePeer.address})",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    WaslPrimaryButton(
                        text = "إعادة الاتصال والبحث",
                        onClick = onReconnectCurrentTransport,
                        modifier = Modifier.weight(1f)
                    )
                    WaslSecondaryButton(
                        text = "قطع الاتصال",
                        onClick = onDisconnectAll,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Switch Transport Path
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WaslColors.ElevatedCardSurface,
            border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "تبديل مسار الاتصال",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "يعمل كل من مسار Wi-Fi ومسار البلوتوث بشكل مستقل تمامًا:",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(12.dp))
                TransportModeSelector(
                    selectedTransport = selectedTransport,
                    onSelectTransport = onSelectTransport
                )
            }
        }

        // Direct IP Fallback for Routers with mDNS / Multicast Blocking
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WaslColors.ElevatedCardSurface,
            border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "اتصال مباشر عبر عنوان IP (بديل احتياطي للشبكة)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "في بعض الشبكات العامة أو الموجهات التي تمنع رسائل الاكتشاف التلقائي (mDNS)، يمكنك كتابة عنوان IP الظاهر على شاشة الطرف الآخر للاتصال به مباشرة:",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = manualIp,
                        onValueChange = { manualIp = it },
                        placeholder = { Text("192.168.1.15") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WaslColors.DeepOlivePrimary,
                            unfocusedBorderColor = WaslColors.CalmBeigeBorder
                        ),
                        modifier = Modifier.weight(2f)
                    )
                    OutlinedTextField(
                        value = manualPort,
                        onValueChange = { manualPort = it },
                        placeholder = { Text("42850") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WaslColors.DeepOlivePrimary,
                            unfocusedBorderColor = WaslColors.CalmBeigeBorder
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                WaslPrimaryButton(
                    text = "اتصال مباشر عبر IP",
                    enabled = manualIp.trim().length >= 7,
                    onClick = { onConnectDirectByIp(manualIp.trim(), manualPort.trim()) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Concise Troubleshooting Guide
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WaslColors.ElevatedCardSurface,
            border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "حلول سريعة للمشكلات الشائعة",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "• عدم ظهور الشخص القريب على Wi-Fi: تأكد من اتصال الهاتفين بنفس الشبكة الفرعية، أو فعّل نقطة اتصال الهوتسبوت (Hotspot) من أحد الهاتفين، أو انتقل إلى مسار البلوتوث.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = WaslColors.CalmBeigeBorder)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• تعذّر اتصال البلوتوث: تأكد من قبول طلب الاقتران على الهاتفين، وأن الطرف الآخر يفتح تطبيق «وَصْل» على وضع البلوتوث.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
