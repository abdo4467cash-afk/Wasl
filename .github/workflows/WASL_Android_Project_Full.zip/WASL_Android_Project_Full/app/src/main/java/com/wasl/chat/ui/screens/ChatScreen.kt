package com.wasl.chat.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wasl.chat.model.ChatMessageEntity
import com.wasl.chat.model.MessageStatus
import com.wasl.chat.model.PeerDevice
import com.wasl.chat.ui.components.WaslAvatarBadge
import com.wasl.chat.ui.components.WaslPrimaryButton
import com.wasl.chat.ui.components.WaslSecondaryButton
import com.wasl.chat.ui.theme.WaslColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
    peer: PeerDevice,
    isPeerLiveConnected: Boolean,
    messages: List<ChatMessageEntity>,
    onSendMessage: (String) -> Unit,
    onRetryFailedMessage: (ChatMessageEntity) -> Unit,
    onReconnectPeer: () -> Unit,
    onNavigateBack: () -> Unit
) {
    var draftText by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val haptics = LocalHapticFeedback.current

    // Auto-scroll smoothly when a new message arrives or is sent
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WaslColors.WarmIvoryBackground)
            .imePadding()
    ) {
        // Editorial Top Header
        Surface(
            color = WaslColors.ElevatedCardSurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        WaslSecondaryButton(
                            text = "→",
                            onClick = onNavigateBack
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        WaslAvatarBadge(
                            avatarId = peer.avatarId,
                            size = 44.dp,
                            isOnline = isPeerLiveConnected
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = peer.nickname,
                                style = MaterialTheme.typography.titleLarge
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isPeerLiveConnected) WaslColors.DeepOlivePrimary
                                            else WaslColors.TerracottaAccent
                                        )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isPeerLiveConnected)
                                        "متصل فعليًا عبر ${peer.transportType.arabicLabel}"
                                    else
                                        "غير متصل حاليًا — ستُحفظ الرسائل لإعادة المحاولة",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isPeerLiveConnected) WaslColors.DeepOlivePrimary else WaslColors.TerracottaAccent
                                    )
                                )
                            }
                        }
                    }

                    if (!isPeerLiveConnected) {
                        WaslSecondaryButton(
                            text = "إعادة اتصال",
                            onClick = onReconnectPeer
                        )
                    }
                }
                HorizontalDivider(color = WaslColors.CalmBeigeBorder)
            }
        }

        // Message History Area
        if (messages.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = WaslColors.ElevatedCardSurface,
                    border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "بداية محادثة محلية مع ${peer.nickname}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "تُرسل الرسائل مباشرة من جهازك إلى جهاز الطرف الآخر دون المرور بأي خادم خارجي. لا تظهر علامة «تم التسليم» إلا بعد وصول تأكيد تقني فعلي من الطرف الآخر.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Spacer(modifier = Modifier.height(10.dp)) }
                items(messages, key = { it.messageId }) { msg ->
                    EditorialMessageBubble(
                        message = msg,
                        onRetryClick = {
                            if (msg.status == MessageStatus.FAILED) {
                                onRetryFailedMessage(msg)
                            }
                        }
                    )
                }
                item { Spacer(modifier = Modifier.height(10.dp)) }
            }
        }

        // Bottom Compose Bar
        Surface(
            color = WaslColors.ElevatedCardSurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                HorizontalDivider(color = WaslColors.CalmBeigeBorder)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = draftText,
                        onValueChange = { if (it.length <= 4000) draftText = it },
                        placeholder = {
                            Text(
                                text = "اكتب رسالتك هنا…",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        },
                        maxLines = 4,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WaslColors.DeepOlivePrimary,
                            unfocusedBorderColor = WaslColors.CalmBeigeBorder,
                            focusedContainerColor = WaslColors.WarmIvoryBackground,
                            unfocusedContainerColor = WaslColors.WarmIvoryBackground
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    WaslPrimaryButton(
                        text = "إرسال",
                        enabled = draftText.trim().isNotEmpty(),
                        onClick = {
                            val clean = draftText.trim()
                            if (clean.isNotEmpty()) {
                                runCatching {
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                                onSendMessage(clean)
                                draftText = ""
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun EditorialMessageBubble(
    message: ChatMessageEntity,
    onRetryClick: () -> Unit
) {
    val isOutgoing = message.isOutgoing
    val bubbleShape = if (isOutgoing) {
        RoundedCornerShape(topStart = 18.dp, topEnd = 4.dp, bottomStart = 18.dp, bottomEnd = 18.dp)
    } else {
        RoundedCornerShape(topStart = 4.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 18.dp)
    }

    val bgColor = if (isOutgoing) WaslColors.OutgoingBubbleBg else WaslColors.IncomingBubbleBg
    val textColor = if (isOutgoing) WaslColors.OutgoingBubbleText else WaslColors.IncomingBubbleText
    val timeFormatted = rememberTimeLabel(message.timestamp)

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isOutgoing) Arrangement.Start else Arrangement.End
    ) {
        Surface(
            shape = bubbleShape,
            color = bgColor,
            border = if (isOutgoing) null else BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
            modifier = Modifier
                .widthIn(min = 96.dp, max = 310.dp)
                .then(
                    if (message.status == MessageStatus.FAILED)
                        Modifier.clickable { onRetryClick() }
                    else Modifier
                )
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyLarge.copy(color = textColor)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = timeFormatted,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isOutgoing)
                                WaslColors.ElevatedCardSurface.copy(alpha = 0.78f)
                            else
                                WaslColors.OliveGraySubtext
                        )
                    )
                    if (isOutgoing) {
                        val statusText = when (message.status) {
                            MessageStatus.SENDING -> "• قيد الإرسال…"
                            MessageStatus.SENT -> "• أُرسلت"
                            MessageStatus.DELIVERED -> "• تم التسليم ✓"
                            MessageStatus.FAILED -> "• تعذّر الإرسال (اضغط للإعادة)"
                        }
                        val statusColor = if (message.status == MessageStatus.FAILED) {
                            WaslColors.TerracottaSoftBg
                        } else {
                            WaslColors.ElevatedCardSurface.copy(alpha = 0.9f)
                        }
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = statusColor,
                                fontWeight = if (message.status == MessageStatus.DELIVERED || message.status == MessageStatus.FAILED)
                                    FontWeight.SemiBold else FontWeight.Normal
                            )
                        )
                    }
                }
            }
        }
    }
}

private fun rememberTimeLabel(timestamp: Long): String {
    return runCatching {
        SimpleDateFormat("hh:mm a", Locale("ar")).format(Date(timestamp))
    }.getOrDefault("")
}
