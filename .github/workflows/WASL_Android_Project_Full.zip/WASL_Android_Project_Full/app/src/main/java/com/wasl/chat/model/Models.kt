package com.wasl.chat.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class TransportType(val arabicLabel: String) {
    WIFI_LAN("شبكة Wi-Fi المحلية"),
    BLUETOOTH("البلوتوث المباشر")
}

enum class ConnectionState(val arabicLabel: String) {
    DISCONNECTED("غير متصل"),
    DISCOVERING("جارٍ البحث عن قريبين…"),
    CONNECTING("جارٍ إنشاء الاتصال…"),
    CONNECTED("متصل فعليًا"),
    ERROR("تعذّر الاتصال")
}

enum class MessageStatus(val arabicLabel: String) {
    SENDING("قيد الإرسال…"),
    SENT("أُرسلت"),
    DELIVERED("تم التسليم"),
    FAILED("تعذّر الإرسال")
}

data class UserProfile(
    val userId: String,
    val nickname: String,
    val avatarId: Int,
    val customAvatarUri: String? = null
)

data class PeerDevice(
    val peerId: String,
    val nickname: String,
    val avatarId: Int,
    val transportType: TransportType,
    val address: String,
    val port: Int = 0,
    val isConnected: Boolean = false,
    val isPaired: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val rssiOrInfo: String = ""
)

@Entity(
    tableName = "messages",
    indices = [
        Index(value = ["messageId"], unique = true),
        Index(value = ["conversationId", "timestamp"])
    ]
)
data class ChatMessageEntity(
    @PrimaryKey
    val messageId: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val senderAvatarId: Int,
    val receiverId: String,
    val content: String,
    val timestamp: Long,
    val isOutgoing: Boolean,
    val status: MessageStatus,
    val transportUsed: TransportType
)

@Entity(tableName = "peers")
data class KnownPeerEntity(
    @PrimaryKey
    val peerId: String,
    val nickname: String,
    val avatarId: Int,
    val lastTransport: TransportType,
    val lastAddress: String,
    val lastPort: Int,
    val lastSeenTimestamp: Long,
    val unreadCount: Int = 0,
    val lastMessagePreview: String = ""
)
