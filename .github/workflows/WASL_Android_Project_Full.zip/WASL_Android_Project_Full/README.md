# تطبيق «وَصْل | WASL» — تطبيق محادثة محلية فاخر (Android Native)

تطبيق محادثة محلية أصلي لنظام Android مبني بلغة **Kotlin** وواجهات **Jetpack Compose** وفق الهوية البصرية **Warm Editorial Minimalism — Minimal Luxury**. يتيح للأشخاص القريبين التواصل المباشر دون إنترنت أو خوادم خارجية أو حسابات سحابية عبر مسارين مستقلين تمامًا:

1. **الشبكة المحلية (Wi-Fi / LAN)**: اكتشاف تلقائي حقيقي عبر `NsdManager` (`_waslchat._tcp.`) مع اتصال مباشر عبر مقابس `ServerSocket` / `Socket` وتأطير طولي (`Length-Prefixed Framing`)، بالإضافة إلى خيار الاتصال المباشر عبر عنوان IP لتجاوز عزل الأجهزة (AP Isolation) في بعض أجهزة الراوتر.
2. **البلوتوث المباشر (Bluetooth Classic RFCOMM)**: مسح الأجهزة القريبة، الاقتران الفعلي (`createBond`)، وفتح قناة اتصال ثنائية عبر UUID مخصص (`8c4e2b90-7a1f-4e92-b15a-9f0e4b6d8a21`).

---

## المعمارية وهيكل المشروع

```text
WASL-Android/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/wasl/chat/
│       │   │   ├── MainActivity.kt                  # نقطة الدخول وإدارة التنقل والأذونات
│       │   │   ├── WaslApplication.kt               # تهيئة قاعدة البيانات والتفضيلات
│       │   │   ├── model/Models.kt                  # نماذج البيانات والكيانات (Room Entities)
│       │   │   ├── protocol/FrameCodec.kt           # بروتوكول التأطير الطولي (4-Byte Length Prefix)
│       │   │   ├── data/WaslDatabase.kt             # قاعدة بيانات Room المحلية ومنع تكرار الرسائل
│       │   │   ├── data/UserPreferencesRepository.kt# حفظ الاسم والصورة محليًا
│       │   │   ├── network/LanDiscoveryAndTransportManager.kt # محرك NSD/mDNS + TCP Socket
│       │   │   ├── bluetooth/BluetoothRfcommManager.kt        # محرك Bluetooth Classic RFCOMM
│       │   │   ├── service/ConnectionForegroundService.kt     # خدمة أمامية للجلسات النشطة
│       │   │   ├── viewmodel/WaslViewModel.kt       # إدارة الحالة الموحدة والتدفقات (StateFlow)
│       │   │   └── ui/
│       │   │       ├── theme/Theme.kt               # لوحة الألوان الدافئة والطباعة التحريرية
│       │   │       ├── components/WaslAvatars.kt    # 8 صور رمزية أصلية مرسومة محليًا + رسوم البحث
│       │   │       ├── components/EditorialComponents.kt # الأزرار، شارات الحالة، مبدل المسارات
│       │   │       └── screens/                     # الشاشات الست الكاملة
│       │   │           ├── OnboardingScreen.kt
│       │   │           ├── HomeScreen.kt
│       │   │           ├── DiscoveryScreen.kt
│       │   │           ├── ChatScreen.kt
│       │   │           ├── ConnectionManagementScreen.kt
│       │   │           └── ProfileSettingsScreen.kt
│       │   └── res/                                 # الموارد العربية RTL والشعار المتجهي
│       └── test/java/com/wasl/chat/
│           └── ProtocolAndFramingTest.kt            # اختبارات التأطير وتبادل الرسائل وتأكيد الاستلام
├── .github/workflows/build-apk.yml                  # بناء ملف APK سحابيًا بضغطة زر عبر GitHub Actions
├── build.gradle.kts
├── settings.gradle.kts
└── build_apk.sh                                     # سكربت البناء المحلي السريع
```

---

## خطوات إنتاج ملف APK القابل للتثبيت

بما أن بيئة الاختبار السحابية المعزولة (Argon VM) لا تحتوي على حزمة `Android SDK` (`aapt2`, `d8`, `android.jar`) ولا تملك اتصالًا بالإنترنت لتنزيلها، فقد تم تجهيز المشروع الكامل ليبنى فورًا بأي من الطريقتين التاليتين دون كتابة أو تعديل سطر كود واحد:

### الطريقة الأولى: عبر Android Studio (موصى بها)
1. فك ضغط ملف `WASL_Android_Project_Full.zip`.
2. افتح المجلد `WASL-Android` داخل **Android Studio** (إصدار Iguana أو أحدث).
3. انتظر ثواني حتى يكتمل `Gradle Sync` التلقائي.
4. من القائمة العلوية اختر: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. سيظهر ملف `app-debug.apk` جاهزًا للتثبيت المباشر على هواتف Android.

### الطريقة الثانية: عبر GitHub Actions (دون تثبيت أي برنامج على حاسوبك)
1. ارفع محتويات مجلد `WASL-Android` إلى مستودع خاص أو عام على GitHub.
2. انتقل إلى تبويب **Actions** داخل المستودع، وستجد سير العمل **Build WASL Android APK** يعمل تلقائيًا.
3. بعد انتهاء البناء (حوالي دقيقتين)، حمّل ملف `WASL-Local-Chat-APK` الذي يحتوي على `app-debug.apk` الجاهز للتثبيت على هاتفك.
