package com.wasl.chat.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wasl.chat.model.ConnectionState
import com.wasl.chat.model.TransportType
import com.wasl.chat.ui.theme.WaslColors

@Composable
fun WaslPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = WaslColors.DeepOlivePrimary,
            contentColor = WaslColors.ElevatedCardSurface,
            disabledContainerColor = WaslColors.CalmBeigeBorder,
            disabledContentColor = WaslColors.OliveGraySubtext
        ),
        modifier = modifier.height(52.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.copy(
                color = if (enabled) WaslColors.ElevatedCardSurface else WaslColors.OliveGraySubtext,
                fontWeight = FontWeight.SemiBold
            )
        )
    }
}

@Composable
fun WaslSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = WaslColors.ElevatedCardSurface,
            contentColor = WaslColors.WarmCharcoalText
        ),
        modifier = modifier.height(48.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge.copy(
                color = WaslColors.WarmCharcoalText,
                fontWeight = FontWeight.Medium
            )
        )
    }
}

/**
 * Editorial Pill Switcher between Wi-Fi LAN and Bluetooth RFCOMM.
 */
@Composable
fun TransportModeSelector(
    selectedTransport: TransportType,
    onSelectTransport: (TransportType) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = WaslColors.SoftLinenSurface,
        border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TransportType.values().forEach { transport ->
                val isSelected = transport == selectedTransport
                val bgColor = if (isSelected) WaslColors.ElevatedCardSurface else WaslColors.SoftLinenSurface
                val textColor = if (isSelected) WaslColors.DeepOlivePrimary else WaslColors.OliveGraySubtext

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(bgColor)
                        .then(
                            if (isSelected) Modifier.border(1.dp, WaslColors.CalmBeigeBorder, RoundedCornerShape(12.dp))
                            else Modifier
                        )
                        .clickable { onSelectTransport(transport) }
                        .padding(vertical = 12.dp, horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = transport.arabicLabel,
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = textColor,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                        )
                    )
                }
            }
        }
    }
}

/**
 * Honest Connection Status Pill — never fakes connectivity.
 */
@Composable
fun ConnectionStatePill(
    connectionState: ConnectionState,
    transportType: TransportType
) {
    val dotColor = when (connectionState) {
        ConnectionState.CONNECTED -> WaslColors.DeepOlivePrimary
        ConnectionState.DISCOVERING, ConnectionState.CONNECTING -> WaslColors.TerracottaAccent
        ConnectionState.ERROR -> WaslColors.TerracottaAccent
        ConnectionState.DISCONNECTED -> WaslColors.OliveGraySubtext
    }

    val containerColor = when (connectionState) {
        ConnectionState.CONNECTED -> WaslColors.SageTintSurface
        ConnectionState.DISCOVERING, ConnectionState.CONNECTING -> WaslColors.TerracottaSoftBg
        ConnectionState.ERROR -> WaslColors.TerracottaSoftBg
        ConnectionState.DISCONNECTED -> WaslColors.SoftLinenSurface
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(containerColor)
            .border(1.dp, WaslColors.CalmBeigeBorder, RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "${transportType.arabicLabel} • ${connectionState.arabicLabel}",
            style = MaterialTheme.typography.labelSmall.copy(
                color = WaslColors.WarmCharcoalText,
                fontWeight = FontWeight.Medium
            )
        )
    }
}

@Composable
fun EditorialNoticeCard(
    message: String,
    onDismiss: (() -> Unit)? = null
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = WaslColors.TerracottaSoftBg,
        border = BorderStroke(1.dp, WaslColors.TerracottaAccent.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "تنبيه الاتصال",
                style = MaterialTheme.typography.labelLarge.copy(
                    color = WaslColors.TerracottaAccent,
                    fontWeight = FontWeight.SemiBold
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = WaslColors.WarmCharcoalText
                )
            )
            if (onDismiss != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "إغلاق التنبيه",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = WaslColors.DeepOlivePrimary,
                        fontWeight = FontWeight.SemiBold
                    ),
                    modifier = Modifier.clickable { onDismiss() }
                )
            }
        }
    }
}
