package com.wasl.chat.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wasl.chat.model.ConnectionState
import com.wasl.chat.model.KnownPeerEntity
import com.wasl.chat.model.PeerDevice
import com.wasl.chat.model.TransportType
import com.wasl.chat.model.UserProfile
import com.wasl.chat.ui.components.ConnectionStatePill
import com.wasl.chat.ui.components.EditorialDiscoveryIllustration
import com.wasl.chat.ui.components.EditorialNoticeCard
import com.wasl.chat.ui.components.TransportModeSelector
import com.wasl.chat.ui.components.WaslAvatarBadge
import com.wasl.chat.ui.components.WaslPrimaryButton
import com.wasl.chat.ui.components.WaslSecondaryButton
import com.wasl.chat.ui.theme.WaslColors

@Composable
fun HomeScreen(
    userProfile: UserProfile,
    selectedTransport: TransportType,
    connectionState: ConnectionState,
    discoveredPeers: List<PeerDevice>,
    knownPeersHistory: List<KnownPeerEntity>,
    statusNotice: String?,
    onSelectTransport: (TransportType) -> Unit,
    onStartDiscoveryScreen: () -> Unit,
    onOpenPeerChat: (PeerDevice) -> Unit,
    onOpenConnectionManagement: () -> Unit,
    onOpenProfileSettings: () -> Unit,
    onDismissNotice: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WaslColors.WarmIvoryBackground)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            // Top Editorial Header with User Greeting & Profile Access
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "أهلًا بك، ${userProfile.nickname}",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    ConnectionStatePill(
                        connectionState = connectionState,
                        transportType = selectedTransport
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WaslSecondaryButton(
                        text = "الشبكة",
                        onClick = onOpenConnectionManagement
                    )
                    WaslAvatarBadge(
                        avatarId = userProfile.avatarId,
                        size = 48.dp,
                        isSelected = true,
                        onClick = onOpenProfileSettings
                    )
                }
            }
        }

        if (!statusNotice.isNullOrBlank()) {
            item {
                EditorialNoticeCard(
                    message = statusNotice,
                    onDismiss = onDismissNotice
                )
            }
        }

        // Transport Mode Selector Card
        item {
            Column {
                Text(
                    text = "وسيلة الاتصال المحلي",
                    style = MaterialTheme.typography.labelLarge.copy(color = WaslColors.OliveGraySubtext)
                )
                Spacer(modifier = Modifier.height(8.dp))
                TransportModeSelector(
                    selectedTransport = selectedTransport,
                    onSelectTransport = onSelectTransport
                )
            }
        }

        // Section Header: Nearby People
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الأشخاص القريبون (${discoveredPeers.size})",
                    style = MaterialTheme.typography.headlineLarge
                )
                Text(
                    text = "لوحة البحث الكاملة ←",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = WaslColors.DeepOlivePrimary,
                        fontWeight = FontWeight.SemiBold
                    ),
                    modifier = Modifier.clickable { onStartDiscoveryScreen() }
                )
            }
        }

        // Real Discovered Peers List (NEVER shows fake/mock peers in production)
        if (discoveredPeers.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = WaslColors.ElevatedCardSurface,
                    border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        EditorialDiscoveryIllustration(
                            isScanning = connectionState == ConnectionState.DISCOVERING
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (connectionState == ConnectionState.DISCOVERING)
                                "جارٍ البحث عن أشخاص قريبين عبر ${selectedTransport.arabicLabel}…"
                            else
                                "لم يتم العثور على أشخاص قريبين بعد",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "تأكد من تشغيل الطرف الآخر لتطبيق «وَصْل» في الجوار، ثم اضغط على زر البحث لاكتشاف الأجهزة المتاحة فعليًا.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        WaslPrimaryButton(
                            text = "البحث عن الأشخاص القريبين",
                            onClick = onStartDiscoveryScreen,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        } else {
            items(discoveredPeers, key = { it.peerId }) { peer ->
                DiscoveredPeerEditorialRow(
                    peer = peer,
                    onStartChat = { onOpenPeerChat(peer) }
                )
            }
        }

        // Saved Local Conversations (Clearly marked with real connection status, never pretending offline peers are live)
        if (knownPeersHistory.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = WaslColors.CalmBeigeBorder)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "سجل المحادثات المحفوظة محليًا",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "تُحفظ محادثاتك السابقة على جهازك. الحالة المعروضة تعكس الاتصال الحقيقي الآن.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            items(knownPeersHistory, key = { "history_${it.peerId}" }) { saved ->
                val liveMatch = discoveredPeers.firstOrNull { it.peerId == saved.peerId }
                val isCurrentlyConnected = liveMatch?.isConnected == true
                SavedPeerHistoryRow(
                    savedPeer = saved,
                    isCurrentlyConnected = isCurrentlyConnected,
                    onClick = {
                        val target = liveMatch ?: PeerDevice(
                            peerId = saved.peerId,
                            nickname = saved.nickname,
                            avatarId = saved.avatarId,
                            transportType = saved.lastTransport,
                            address = saved.lastAddress,
                            port = saved.lastPort,
                            isConnected = false
                        )
                        onOpenPeerChat(target)
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun DiscoveredPeerEditorialRow(
    peer: PeerDevice,
    onStartChat: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = WaslColors.ElevatedCardSurface,
        border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                WaslAvatarBadge(
                    avatarId = peer.avatarId,
                    size = 54.dp,
                    isOnline = peer.isConnected
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = peer.nickname,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = if (peer.isConnected) "متصل فعليًا • جاهز للمحادثة"
                        else peer.rssiOrInfo.ifBlank { peer.transportType.arabicLabel },
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = if (peer.isConnected) WaslColors.DeepOlivePrimary else WaslColors.OliveGraySubtext
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            WaslPrimaryButton(
                text = if (peer.isConnected) "فتح المحادثة" else "بدء المحادثة",
                onClick = onStartChat
            )
        }
    }
}

@Composable
private fun SavedPeerHistoryRow(
    savedPeer: KnownPeerEntity,
    isCurrentlyConnected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = WaslColors.ElevatedCardSurface,
        border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                WaslAvatarBadge(
                    avatarId = savedPeer.avatarId,
                    size = 46.dp,
                    isOnline = isCurrentlyConnected
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = savedPeer.nickname,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isCurrentlyConnected) "• متصل الآن" else "• غير متصل حاليًا",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (isCurrentlyConnected) WaslColors.DeepOlivePrimary else WaslColors.OliveGraySubtext
                            )
                        )
                    }
                    if (savedPeer.lastMessagePreview.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = savedPeer.lastMessagePreview,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1
                        )
                    }
                }
            }

            if (savedPeer.unreadCount > 0) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(WaslColors.TerracottaAccent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = savedPeer.unreadCount.toString(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = WaslColors.ElevatedCardSurface,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}
