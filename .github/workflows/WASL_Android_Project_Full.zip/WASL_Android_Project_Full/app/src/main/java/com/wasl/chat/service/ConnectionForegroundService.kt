package com.wasl.chat.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.wasl.chat.MainActivity
import com.wasl.chat.R

/**
 * Lightweight Foreground Service activated ONLY when an active local session is established
 * so Android does not aggressively kill the socket when the user briefly switches apps.
 */
class ConnectionForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val transportLabel = intent?.getStringExtra(EXTRA_TRANSPORT_LABEL) ?: "اتصال محلي نشط"
        val notification = buildNotification(transportLabel)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(transportLabel: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_wasl_logo)
            .setContentTitle("وَصْل | جلسة محادثة محلية نشطة")
            .setContentText(transportLabel)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "اتصالات وَصْل المحلية",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار هادئ يظهر فقط أثناء وجود اتصال محلي نشط عبر Wi-Fi أو البلوتوث"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "wasl_active_session_channel"
        private const val NOTIFICATION_ID = 4201
        const val ACTION_START = "com.wasl.chat.action.START_SESSION_SERVICE"
        const val ACTION_STOP = "com.wasl.chat.action.STOP_SESSION_SERVICE"
        const val EXTRA_TRANSPORT_LABEL = "extra_transport_label"
    }
}
