package com.wasl.chat.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import com.wasl.chat.model.ConnectionState
import com.wasl.chat.model.PeerDevice
import com.wasl.chat.model.TransportType
import com.wasl.chat.model.UserProfile
import com.wasl.chat.protocol.FrameCodec
import com.wasl.chat.protocol.PacketType
import com.wasl.chat.protocol.WirePacket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Real Local Area Network (Wi-Fi / LAN) Discovery & Peer-to-Peer Session Engine.
 *
 * Features:
 * 1. NSD / mDNS advertisement and discovery (`_waslchat._tcp.`).
 * 2. MulticastLock acquisition to ensure mDNS packets are not dropped by Wi-Fi drivers.
 * 3. Real TCP ServerSocket with dynamic or default port (42850) for multi-peer sessions.
 * 4. Length-prefixed framing (`FrameCodec`) over buffered TCP streams.
 * 5. Automatic delivery receipts (`DELIVERY_ACK`) only when the remote peer physically receives the frame.
 * 6. NetworkCallback monitoring IP changes or Wi-Fi drops, plus direct IP:Port fallback when router AP isolation blocks mDNS.
 */
class LanDiscoveryAndTransportManager(
    private val context: Context,
    private val getLocalProfile: () -> UserProfile?
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val nsdManager: NsdManager? =
        context.applicationContext.getSystemService(Context.NSD_SERVICE) as? NsdManager
    private val wifiManager: WifiManager? =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val connectivityManager: ConnectivityManager? =
        context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private var multicastLock: WifiManager.MulticastLock? = null
    private var serverSocket: ServerSocket? = null
    private var serverAcceptJob: Job? = null
    private var heartbeatJob: Job? = null

    private var isServiceRegistered = false
    private var isDiscoveryActive = false
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    private val activeConnections = ConcurrentHashMap<String, ActiveLanConnection>()

    private val _discoveredPeers = MutableStateFlow<List<PeerDevice>>(emptyList())
    val discoveredPeers: StateFlow<List<PeerDevice>> = _discoveredPeers.asStateFlow()

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _localIpAndPort = MutableStateFlow<String>("غير متاح على الشبكة")
    val localIpAndPort: StateFlow<String> = _localIpAndPort.asStateFlow()

    private val _statusNotice = MutableStateFlow<String?>(null)
    val statusNotice: StateFlow<String?> = _statusNotice.asStateFlow()

    private val _incomingPackets = MutableSharedFlow<WirePacket>(extraBufferCapacity = 64)
    val incomingPackets: SharedFlow<WirePacket> = _incomingPackets.asSharedFlow()

    private class ActiveLanConnection(
        val peerId: String,
        val socket: Socket,
        val input: DataInputStream,
        val output: DataOutputStream,
        val readerJob: Job
    )

    init {
        registerNetworkMonitor()
    }

    private fun registerNetworkMonitor() {
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET)
            .build()
        runCatching {
            connectivityManager?.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    refreshLocalIpDisplay()
                }

                override fun onLost(network: Network) {
                    _statusNotice.value = "انقطع الاتصال بشبكة Wi-Fi المحلية."
                    closeAllActiveConnections()
                    refreshLocalIpDisplay()
                }
            })
        }
    }

    fun refreshLocalIpDisplay() {
        val ip = getDeviceLanIpAddress()
        val port = serverSocket?.localPort ?: DEFAULT_PORT
        _localIpAndPort.value = if (ip != null) "$ip:$port" else "غير متصل بشبكة Wi-Fi"
    }

    fun startServerAndDiscovery() {
        val profile = getLocalProfile()
        if (profile == null) {
            _statusNotice.value = "يرجى إعداد الاسم المستعار أولًا قبل بدء الاكتشاف."
            return
        }

        val ip = getDeviceLanIpAddress()
        if (ip == null) {
            _connectionState.value = ConnectionState.ERROR
            _statusNotice.value = "الجهاز غير متصل بشبكة Wi-Fi محلية حاليًا. فعّل Wi-Fi أو انتقل إلى مسار البلوتوث."
            return
        }

        _statusNotice.value = null
        acquireMulticastLock()
        startTcpServerIfNeeded(profile)
        registerNsdService(profile)
        startNsdDiscovery(profile)
        startHeartbeatLoop()
    }

    fun stopDiscoveryOnly() {
        stopNsdDiscovery()
        releaseMulticastLock()
        if (activeConnections.isEmpty()) {
            _connectionState.value = ConnectionState.DISCONNECTED
        } else {
            _connectionState.value = ConnectionState.CONNECTED
        }
    }

    fun stopAll() {
        stopNsdDiscovery()
        unregisterNsdService()
        releaseMulticastLock()
        heartbeatJob?.cancel()
        serverAcceptJob?.cancel()
        runCatching { serverSocket?.close() }
        serverSocket = null
        closeAllActiveConnections()
        _connectionState.value = ConnectionState.DISCONNECTED
    }

    private fun startTcpServerIfNeeded(profile: UserProfile) {
        if (serverSocket != null && !serverSocket!!.isClosed) {
            refreshLocalIpDisplay()
            return
        }
        serverAcceptJob?.cancel()
        serverAcceptJob = scope.launch {
            try {
                val srv = try {
                    ServerSocket(DEFAULT_PORT)
                } catch (e: IOException) {
                    ServerSocket(0) // Bind to any available OS port if 42850 is busy
                }
                serverSocket = srv
                refreshLocalIpDisplay()

                while (isActive && !srv.isClosed) {
                    val clientSocket = srv.accept()
                    clientSocket.tcpNoDelay = true
                    clientSocket.keepAlive = true
                    handleConnectedSocket(clientSocket, initiatedByUs = false, expectedPeer = null)
                }
            } catch (e: IOException) {
                if (isActive) {
                    _statusNotice.value = "توقف خادم المحادثة المحلي: ${e.localizedMessage ?: "خطأ في الشبكة"}"
                }
            }
        }
    }

    private fun registerNsdService(profile: UserProfile) {
        if (isServiceRegistered || nsdManager == null) return
        val port = serverSocket?.localPort ?: DEFAULT_PORT
        val safeNick = profile.nickname.replace("|", "").replace(":", "").take(24)
        // Encode userId, avatarId, and nickname in service name for reliable compatibility across Android API levels
        val serviceName = "WASL_${profile.userId}_${profile.avatarId}_$safeNick"

        val serviceInfo = NsdServiceInfo().apply {
            this.serviceName = serviceName
            this.serviceType = SERVICE_TYPE
            this.port = port
        }

        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {
                isServiceRegistered = true
            }

            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                isServiceRegistered = false
                _statusNotice.value = "تعذّر تسجيل الإعلان المحلي عبر الشبكة (رمز $errorCode). ما يزال بإمكانك الاتصال المباشر عبر IP."
            }

            override fun onServiceUnregistered(arg0: NsdServiceInfo) {
                isServiceRegistered = false
            }

            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
        }

        registrationListener = listener
        runCatching {
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, listener)
        }.onFailure {
            _statusNotice.value = "تعذّر تفعيل خدمة NSD على هذا الجهاز."
        }
    }

    private fun unregisterNsdService() {
        if (!isServiceRegistered || nsdManager == null) return
        registrationListener?.let { listener ->
            runCatching { nsdManager.unregisterService(listener) }
        }
        isServiceRegistered = false
        registrationListener = null
    }

    private fun startNsdDiscovery(localProfile: UserProfile) {
        if (isDiscoveryActive || nsdManager == null) return
        _connectionState.value = if (activeConnections.isEmpty()) ConnectionState.DISCOVERING else ConnectionState.CONNECTED

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {
                isDiscoveryActive = true
            }

            override fun onServiceFound(service: NsdServiceInfo) {
                if (!service.serviceType.contains("_waslchat")) return
                if (service.serviceName.contains(localProfile.userId)) return // Ignore self

                nsdManager.resolveService(service, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                        // Ignore transient resolve conflict
                    }

                    override fun onServiceResolved(resolvedInfo: NsdServiceInfo) {
                        val hostAddress = resolvedInfo.host?.hostAddress ?: return
                        val resolvedPort = resolvedInfo.port
                        val parsed = parseWaslServiceName(resolvedInfo.serviceName)
                        if (parsed.first == localProfile.userId) return

                        val peer = PeerDevice(
                            peerId = parsed.first,
                            nickname = parsed.third,
                            avatarId = parsed.second,
                            transportType = TransportType.WIFI_LAN,
                            address = hostAddress,
                            port = resolvedPort,
                            isConnected = activeConnections.containsKey(parsed.first),
                            isPaired = true,
                            lastSeenTimestamp = System.currentTimeMillis(),
                            rssiOrInfo = "$hostAddress:$resolvedPort"
                        )
                        upsertDiscoveredPeer(peer)
                    }
                })
            }

            override fun onServiceLost(service: NsdServiceInfo) {
                val parsed = parseWaslServiceName(service.serviceName)
                _discoveredPeers.update { list ->
                    list.filterNot { it.peerId == parsed.first && !it.isConnected }
                }
            }

            override fun onDiscoveryStopped(serviceType: String) {
                isDiscoveryActive = false
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                isDiscoveryActive = false
                _statusNotice.value = "تعذّر بدء اكتشاف الشبكة (رمز $errorCode). قد يمنع الراوتر رسائل Multicast."
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                isDiscoveryActive = false
            }
        }

        discoveryListener = listener
        runCatching {
            nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
        }.onFailure {
            _statusNotice.value = "تعذّر تشغيل البحث الشبكي المحلي: ${it.localizedMessage}"
        }
    }

    private fun stopNsdDiscovery() {
        if (!isDiscoveryActive || nsdManager == null) return
        discoveryListener?.let { listener ->
            runCatching { nsdManager.stopServiceDiscovery(listener) }
        }
        isDiscoveryActive = false
        discoveryListener = null
    }

    /**
     * Fallback direct connection by IP & Port when public Wi-Fi / router AP isolation
     * blocks mDNS multicast packets between peers.
     */
    fun connectToPeerByIp(ipAddress: String, port: Int = DEFAULT_PORT, knownPeer: PeerDevice? = null) {
        val cleanIp = ipAddress.trim()
        if (cleanIp.isEmpty()) {
            _statusNotice.value = "يرجى إدخال عنوان IP محلي صحيح."
            return
        }
        scope.launch {
            _connectionState.value = ConnectionState.CONNECTING
            try {
                val socket = Socket()
                socket.tcpNoDelay = true
                socket.keepAlive = true
                socket.connect(InetSocketAddress(cleanIp, port), SOCKET_CONNECT_TIMEOUT_MS)
                handleConnectedSocket(socket, initiatedByUs = true, expectedPeer = knownPeer)
            } catch (e: IOException) {
                _connectionState.value = if (activeConnections.isNotEmpty()) ConnectionState.CONNECTED else ConnectionState.ERROR
                _statusNotice.value = "تعذّر الاتصال بالعنوان $cleanIp:$port. تأكد من وجود الجهازين على نفس الشبكة وعدم تفعيل عزل الأجهزة (AP Isolation) في الراوتر."
            }
        }
    }

    fun connectToDiscoveredPeer(peer: PeerDevice) {
        if (activeConnections.containsKey(peer.peerId)) {
            _connectionState.value = ConnectionState.CONNECTED
            return
        }
        connectToPeerByIp(peer.address, if (peer.port > 0) peer.port else DEFAULT_PORT, peer)
    }

    private fun handleConnectedSocket(
        socket: Socket,
        initiatedByUs: Boolean,
        expectedPeer: PeerDevice?
    ) {
        val localProfile = getLocalProfile() ?: run {
            runCatching { socket.close() }
            return
        }

        val input = DataInputStream(BufferedInputStream(socket.getInputStream()))
        val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream()))

        val readerJob = scope.launch {
            var remotePeerId: String? = expectedPeer?.peerId
            try {
                // Immediately send our HELLO handshake frame
                val helloPacket = WirePacket(
                    type = PacketType.HELLO,
                    packetId = UUID.randomUUID().toString(),
                    sessionId = "lan_${localProfile.userId}",
                    senderId = localProfile.userId,
                    senderName = localProfile.nickname,
                    senderAvatarId = localProfile.avatarId,
                    payload = "${socket.localAddress?.hostAddress ?: ""}:${serverSocket?.localPort ?: DEFAULT_PORT}",
                    timestamp = System.currentTimeMillis()
                )
                FrameCodec.writeFrame(output, helloPacket)

                while (isActive && !socket.isClosed) {
                    val packet = FrameCodec.readFrame(input)
                    when (packet.type) {
                        PacketType.HELLO -> {
                            remotePeerId = packet.senderId
                            val remoteHost = socket.inetAddress?.hostAddress ?: expectedPeer?.address ?: ""
                            val remotePort = expectedPeer?.port ?: DEFAULT_PORT
                            val conn = ActiveLanConnection(
                                peerId = packet.senderId,
                                socket = socket,
                                input = input,
                                output = output,
                                readerJob = coroutineContext[Job]!!
                            )
                            activeConnections[packet.senderId]?.let { old ->
                                runCatching { old.socket.close() }
                            }
                            activeConnections[packet.senderId] = conn
                            _connectionState.value = ConnectionState.CONNECTED
                            _statusNotice.value = null

                            val updatedPeer = PeerDevice(
                                peerId = packet.senderId,
                                nickname = packet.senderName,
                                avatarId = packet.senderAvatarId,
                                transportType = TransportType.WIFI_LAN,
                                address = remoteHost,
                                port = remotePort,
                                isConnected = true,
                                isPaired = true,
                                lastSeenTimestamp = System.currentTimeMillis(),
                                rssiOrInfo = "متصل عبر Wi-Fi ($remoteHost)"
                            )
                            upsertDiscoveredPeer(updatedPeer)
                            _incomingPackets.emit(packet)
                        }

                        PacketType.CHAT_MESSAGE -> {
                            // Send immediate technical DELIVERY_ACK frame back to sender
                            val ack = WirePacket(
                                type = PacketType.DELIVERY_ACK,
                                packetId = UUID.randomUUID().toString(),
                                sessionId = packet.sessionId,
                                senderId = localProfile.userId,
                                senderName = localProfile.nickname,
                                senderAvatarId = localProfile.avatarId,
                                payload = "ACK",
                                timestamp = System.currentTimeMillis(),
                                ackTargetMessageId = packet.packetId
                            )
                            runCatching { FrameCodec.writeFrame(output, ack) }
                            _incomingPackets.emit(packet)
                        }

                        PacketType.DELIVERY_ACK -> {
                            _incomingPackets.emit(packet)
                        }

                        PacketType.PING -> {
                            val pong = WirePacket(
                                type = PacketType.PONG,
                                packetId = UUID.randomUUID().toString(),
                                sessionId = packet.sessionId,
                                senderId = localProfile.userId,
                                senderName = localProfile.nickname,
                                senderAvatarId = localProfile.avatarId,
                                payload = "PONG",
                                timestamp = System.currentTimeMillis()
                            )
                            runCatching { FrameCodec.writeFrame(output, pong) }
                        }

                        PacketType.PONG -> {
                            // Connection verified alive
                        }

                        PacketType.DISCONNECT -> {
                            break
                        }
                    }
                }
            } catch (e: IOException) {
                // Socket closed or dropped
            } finally {
                runCatching { socket.close() }
                remotePeerId?.let { id ->
                    activeConnections.remove(id)
                    markPeerDisconnected(id)
                }
                _connectionState.value =
                    if (activeConnections.isNotEmpty()) ConnectionState.CONNECTED
                    else if (isDiscoveryActive) ConnectionState.DISCOVERING
                    else ConnectionState.DISCONNECTED
            }
        }
    }

    suspend fun sendPacketToPeer(peerId: String, packet: WirePacket): Boolean = withContext(Dispatchers.IO) {
        val conn = activeConnections[peerId] ?: return@withContext false
        return@withContext try {
            FrameCodec.writeFrame(conn.output, packet)
            true
        } catch (e: IOException) {
            activeConnections.remove(peerId)
            runCatching { conn.socket.close() }
            markPeerDisconnected(peerId)
            false
        }
    }

    fun disconnectPeer(peerId: String) {
        val conn = activeConnections.remove(peerId) ?: return
        scope.launch {
            val profile = getLocalProfile()
            if (profile != null) {
                val bye = WirePacket(
                    type = PacketType.DISCONNECT,
                    packetId = UUID.randomUUID().toString(),
                    sessionId = "lan_${profile.userId}",
                    senderId = profile.userId,
                    senderName = profile.nickname,
                    senderAvatarId = profile.avatarId,
                    payload = "BYE",
                    timestamp = System.currentTimeMillis()
                )
                runCatching { FrameCodec.writeFrame(conn.output, bye) }
            }
            runCatching { conn.socket.close() }
            conn.readerJob.cancel()
            markPeerDisconnected(peerId)
            _connectionState.value =
                if (activeConnections.isNotEmpty()) ConnectionState.CONNECTED else ConnectionState.DISCONNECTED
        }
    }

    fun isPeerConnected(peerId: String): Boolean {
        val conn = activeConnections[peerId] ?: return false
        return !conn.socket.isClosed && conn.socket.isConnected
    }

    private fun closeAllActiveConnections() {
        activeConnections.keys.toList().forEach { peerId ->
            val conn = activeConnections.remove(peerId)
            runCatching { conn?.socket?.close() }
            conn?.readerJob?.cancel()
            markPeerDisconnected(peerId)
        }
    }

    private fun startHeartbeatLoop() {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(15_000L)
                val profile = getLocalProfile() ?: continue
                activeConnections.forEach { (peerId, conn) ->
                    val ping = WirePacket(
                        type = PacketType.PING,
                        packetId = UUID.randomUUID().toString(),
                        sessionId = "lan_${profile.userId}",
                        senderId = profile.userId,
                        senderName = profile.nickname,
                        senderAvatarId = profile.avatarId,
                        payload = "PING",
                        timestamp = System.currentTimeMillis()
                    )
                    try {
                        FrameCodec.writeFrame(conn.output, ping)
                    } catch (e: IOException) {
                        activeConnections.remove(peerId)
                        runCatching { conn.socket.close() }
                        markPeerDisconnected(peerId)
                    }
                }
            }
        }
    }

    private fun upsertDiscoveredPeer(peer: PeerDevice) {
        _discoveredPeers.update { current ->
            val mutable = current.toMutableList()
            val idx = mutable.indexOfFirst { it.peerId == peer.peerId }
            if (idx >= 0) {
                mutable[idx] = peer
            } else {
                mutable.add(0, peer)
            }
            mutable
        }
    }

    private fun markPeerDisconnected(peerId: String) {
        _discoveredPeers.update { current ->
            current.map {
                if (it.peerId == peerId) it.copy(isConnected = false) else it
            }
        }
    }

    private fun parseWaslServiceName(rawName: String): Triple<String, Int, String> {
        // Expected format: WASL_<userId>_<avatarId>_<nickname>
        val parts = rawName.split("_", limit = 4)
        return if (parts.size >= 4 && parts[0].startsWith("WASL")) {
            val userId = "wasl_" + parts[1].removePrefix("wasl_")
            val avatarId = parts[2].toIntOrNull()?.coerceIn(0, 7) ?: 0
            val nickname = parts[3].ifBlank { "مستخدم قريب" }
            Triple(userId, avatarId, nickname)
        } else {
            Triple("peer_${rawName.hashCode()}", 0, rawName.take(20))
        }
    }

    private fun acquireMulticastLock() {
        if (multicastLock?.isHeld == true) return
        runCatching {
            multicastLock = wifiManager?.createMulticastLock("WaslLanMulticastLock")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        }
    }

    private fun releaseMulticastLock() {
        runCatching {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        }
    }

    private fun getDeviceLanIpAddress(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            for (intf in interfaces) {
                if (!intf.isUp || intf.isLoopback) continue
                for (addr in intf.inetAddresses) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val ip = addr.hostAddress ?: continue
                        if (!ip.startsWith("169.254.")) {
                            return ip
                        }
                    }
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        const val SERVICE_TYPE = "_waslchat._tcp."
        const val DEFAULT_PORT = 42850
        private const val SOCKET_CONNECT_TIMEOUT_MS = 6000
    }
}
