package com.wasl.chat.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wasl.chat.model.ConnectionState
import com.wasl.chat.model.PeerDevice
import com.wasl.chat.model.TransportType
import com.wasl.chat.ui.components.EditorialDiscoveryIllustration
import com.wasl.chat.ui.components.EditorialNoticeCard
import com.wasl.chat.ui.components.TransportModeSelector
import com.wasl.chat.ui.components.WaslAvatarBadge
import com.wasl.chat.ui.components.WaslPrimaryButton
import com.wasl.chat.ui.components.WaslSecondaryButton
import com.wasl.chat.ui.theme.WaslColors

@Composable
fun DiscoveryScreen(
    selectedTransport: TransportType,
    connectionState: ConnectionState,
    discoveredPeers: List<PeerDevice>,
    localIpAndPort: String,
    statusNotice: String?,
    onSelectTransport: (TransportType) -> Unit,
    onStartDiscovery: () -> Unit,
    onStopDiscovery: () -> Unit,
    onConnectPeer: (PeerDevice) -> Unit,
    onNavigateBack: () -> Unit
) {
    val isScanning = connectionState == ConnectionState.DISCOVERING || connectionState == ConnectionState.CONNECTING

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WaslColors.WarmIvoryBackground)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            WaslSecondaryButton(text = "→ رجوع", onClick = onNavigateBack)
            Text(
                text = "اكتشاف الأجهزة القريبة",
                style = MaterialTheme.typography.headlineMedium
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        TransportModeSelector(
            selectedTransport = selectedTransport,
            onSelectTransport = onSelectTransport
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Calm Status & Control Card (No infinite battery-draining animations)
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WaslColors.ElevatedCardSurface,
            border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "المسار النشط: ${selectedTransport.arabicLabel}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (selectedTransport == TransportType.WIFI_LAN)
                                "عنوان جهازك المحلي: $localIpAndPort"
                            else
                                "الاقتران والاتصال عبر قناة Bluetooth RFCOMM",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Text(
                        text = "${discoveredPeers.size} أجهزة",
                        style = MaterialTheme.typography.titleLarge.copy(color = WaslColors.DeepOlivePrimary)
                    )
                }

                if (isScanning) {
                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        color = WaslColors.DeepOlivePrimary,
                        trackColor = WaslColors.SoftLinenSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    WaslPrimaryButton(
                        text = if (isScanning) "إعادة المحاولة" else "بدء البحث الآن",
                        onClick = onStartDiscovery,
                        modifier = Modifier.weight(1f)
                    )
                    if (isScanning) {
                        WaslSecondaryButton(
                            text = "إيقاف البحث",
                            onClick = onStopDiscovery,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        if (!statusNotice.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            EditorialNoticeCard(message = statusNotice)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "النتائج الحقيقية المكتشفة (${discoveredPeers.size})",
            style = MaterialTheme.typography.titleLarge
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (discoveredPeers.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = WaslColors.ElevatedCardSurface,
                border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    EditorialDiscoveryIllustration(isScanning = isScanning)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isScanning) "نبحث بهدوء عن الأجهزة القريبة…" else "لا توجد أجهزة مستجيبة في النطاق حاليًا",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (selectedTransport == TransportType.WIFI_LAN)
                            "تأكد من اتصال الجهازين بنفس شبكة Wi-Fi، أو افتح «إدارة الاتصال» للاتصال المباشر عبر عنوان IP إذا كان الراوتر يعزل الأجهزة."
                        else
                            "تأكد من تفعيل البلوتوث ومنح الأذونات اللازمة على كلا الجهازين.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(discoveredPeers, key = { it.peerId }) { peer ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = WaslColors.ElevatedCardSurface,
                        border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                WaslAvatarBadge(
                                    avatarId = peer.avatarId,
                                    size = 50.dp,
                                    isOnline = peer.isConnected
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = peer.nickname,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Text(
                                        text = peer.rssiOrInfo.ifBlank { peer.address },
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                            WaslPrimaryButton(
                                text = if (peer.isConnected) "متصل • محادثة" else "اتصال ومحادثة",
                                onClick = { onConnectPeer(peer) }
                            )
                        }
                    }
                }
            }
        }
    }
}
