package com.wasl.chat.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wasl.chat.model.UserProfile
import com.wasl.chat.ui.components.WaslAvatarBadge
import com.wasl.chat.ui.components.WaslAvatarCatalog
import com.wasl.chat.ui.components.WaslPrimaryButton
import com.wasl.chat.ui.components.WaslSecondaryButton
import com.wasl.chat.ui.theme.WaslColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileSettingsScreen(
    userProfile: UserProfile,
    onSaveProfile: (nickname: String, avatarId: Int) -> Unit,
    onRequestPermissionsAgain: () -> Unit,
    onClearLocalHistory: () -> Unit,
    onNavigateBack: () -> Unit
) {
    var nickname by rememberSaveable { mutableStateOf(userProfile.nickname) }
    var selectedAvatarId by rememberSaveable { mutableIntStateOf(userProfile.avatarId) }
    var showSavedBanner by rememberSaveable { mutableStateOf(false) }
    var showConfirmDeleteDialog by rememberSaveable { mutableStateOf(false) }

    if (showConfirmDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDeleteDialog = false },
            containerColor = WaslColors.ElevatedCardSurface,
            title = {
                Text(
                    text = "مسح سجل المحادثات المحلية",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف جميع الرسائل والمحادثات المحفوظة على هذا الجهاز نهائيًا؟ لا يمكن التراجع عن هذا الإجراء.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = WaslColors.WarmCharcoalText)
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearLocalHistory()
                        showConfirmDeleteDialog = false
                    }
                ) {
                    Text(
                        text = "نعم، احذف السجل",
                        color = WaslColors.TerracottaAccent,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDeleteDialog = false }) {
                    Text(
                        text = "إلغاء",
                        color = WaslColors.DeepOlivePrimary
                    )
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WaslColors.WarmIvoryBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            WaslSecondaryButton(text = "→ رجوع", onClick = onNavigateBack)
            Text(
                text = "الملف الشخصي والإعدادات",
                style = MaterialTheme.typography.headlineMedium
            )
        }

        // Profile Edit Card
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WaslColors.ElevatedCardSurface,
            border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "تعديل الهوية المحلية",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = nickname,
                    onValueChange = {
                        if (it.length <= 32) {
                            nickname = it
                            showSavedBanner = false
                        }
                    },
                    label = { Text("الاسم المستعار") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = WaslColors.DeepOlivePrimary,
                        unfocusedBorderColor = WaslColors.CalmBeigeBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "الرمز الشخصي: ${WaslAvatarCatalog.getSpec(selectedAvatarId).arabicTitle}",
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(modifier = Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    WaslAvatarCatalog.avatars.forEach { spec ->
                        WaslAvatarBadge(
                            avatarId = spec.id,
                            size = 54.dp,
                            isSelected = selectedAvatarId == spec.id,
                            onClick = {
                                selectedAvatarId = spec.id
                                showSavedBanner = false
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                WaslPrimaryButton(
                    text = if (showSavedBanner) "تم حفظ التعديلات محليًا ✓" else "حفظ التغييرات",
                    enabled = nickname.trim().length >= 2,
                    onClick = {
                        onSaveProfile(nickname.trim(), selectedAvatarId)
                        showSavedBanner = true
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Permissions & Privacy Card
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WaslColors.ElevatedCardSurface,
            border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "الأذونات والخصوصية",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "يستخدم تطبيق «وَصْل» أذونات الشبكة القريبة والبلوتوث فقط للعثور على الأشخاص من حولك وتبادل الرسائل معهم مباشرة. لا يمنح اكتشاف الأشخاص أي جهاز آخر صلاحية الوصول إلى ملفات هاتفك، ولا يرسل التطبيق أي بيانات أو تحليلات إلى الإنترنت.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(12.dp))
                WaslSecondaryButton(
                    text = "فحص وتحديث أذونات الاتصال القريب",
                    onClick = onRequestPermissionsAgain,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Local Data Management & App Info Card
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WaslColors.ElevatedCardSurface,
            border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "البيانات المحلية ومعلومات الإصدار",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(10.dp))
                WaslSecondaryButton(
                    text = "مسح سجل المحادثات المحلية…",
                    onClick = { showConfirmDeleteDialog = true },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = WaslColors.CalmBeigeBorder)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "تطبيق وَصْل | WASL — الإصدار 1.0.0",
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "هوية بصرية: Warm Editorial Minimalism • اتصال محلي مباشر عبر NSD/TCP وBluetooth RFCOMM دون خوادم سحابية.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
