package com.wasl.chat.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.wasl.chat.model.ConnectionState
import com.wasl.chat.model.PeerDevice
import com.wasl.chat.model.TransportType
import com.wasl.chat.model.UserProfile
import com.wasl.chat.protocol.FrameCodec
import com.wasl.chat.protocol.PacketType
import com.wasl.chat.protocol.WirePacket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Real Bluetooth Classic RFCOMM Discovery, Pairing, Server & Client Manager.
 *
 * Uses a dedicated UUID for WASL (`8c4e2b90-7a1f-4e92-b15a-9f0e4b6d8a21`) and operates
 * completely independently of the Wi-Fi LAN transport path.
 */
@SuppressLint("MissingPermission")
class BluetoothRfcommManager(
    private val context: Context,
    private val getLocalProfile: () -> UserProfile?
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val bluetoothManager: BluetoothManager? =
        context.applicationContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private var rfcommServerSocket: BluetoothServerSocket? = null
    private var serverAcceptJob: Job? = null
    private var receiverRegistered = false

    private val activeConnections = ConcurrentHashMap<String, ActiveBtConnection>()

    private val _discoveredPeers = MutableStateFlow<List<PeerDevice>>(emptyList())
    val discoveredPeers: StateFlow<List<PeerDevice>> = _discoveredPeers.asStateFlow()

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _statusNotice = MutableStateFlow<String?>(null)
    val statusNotice: StateFlow<String?> = _statusNotice.asStateFlow()

    private val _incomingPackets = MutableSharedFlow<WirePacket>(extraBufferCapacity = 64)
    val incomingPackets: SharedFlow<WirePacket> = _incomingPackets.asSharedFlow()

    private class ActiveBtConnection(
        val peerId: String,
        val macAddress: String,
        val socket: BluetoothSocket,
        val input: DataInputStream,
        val output: DataOutputStream,
        val readerJob: Job
    )

    private val btDiscoveryReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    if (!hasBluetoothConnectPermission()) return
                    val device: BluetoothDevice? =
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                    val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE)
                    device?.let { onBluetoothDeviceFound(it, rssi.toInt()) }
                }

                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    _connectionState.value =
                        if (activeConnections.isNotEmpty()) ConnectionState.CONNECTED else ConnectionState.DISCOVERING
                }

                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    if (activeConnections.isEmpty()) {
                        _connectionState.value = ConnectionState.DISCONNECTED
                    } else {
                        _connectionState.value = ConnectionState.CONNECTED
                    }
                }

                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    if (!hasBluetoothConnectPermission()) return
                    val device: BluetoothDevice? =
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                    val bondState = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE)
                    if (device != null && bondState == BluetoothDevice.BOND_BONDED) {
                        _statusNotice.value = "تم الاقتران بالجهاز ${device.name ?: device.address} بنجاح. جارٍ فتح قناة المحادثة…"
                        connectToBluetoothDevice(device.address)
                    } else if (device != null && bondState == BluetoothDevice.BOND_NONE) {
                        _statusNotice.value = "تم إلغاء أو تعذّر الاقتران بالجهاز ${device.name ?: device.address}."
                    }
                }

                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    if (state == BluetoothAdapter.STATE_OFF) {
                        _statusNotice.value = "تم إيقاف البلوتوث على الجهاز."
                        stopAll()
                    }
                }
            }
        }
    }

    fun isBluetoothSupported(): Boolean = bluetoothAdapter != null

    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    fun hasBluetoothPermissions(): Boolean {
        return hasBluetoothScanPermission() && hasBluetoothConnectPermission()
    }

    private fun hasBluetoothScanPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun hasBluetoothConnectPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun startRfcommServerAndDiscovery() {
        if (!isBluetoothSupported()) {
            _connectionState.value = ConnectionState.ERROR
            _statusNotice.value = "هذا الجهاز لا يحتوي على عتاد البلوتوث."
            return
        }
        if (!hasBluetoothPermissions()) {
            _connectionState.value = ConnectionState.ERROR
            _statusNotice.value = "يلزم منح أذونات البلوتوث للبحث عن الأجهزة القريبة والاتصال بها."
            return
        }
        if (!isBluetoothEnabled()) {
            _connectionState.value = ConnectionState.ERROR
            _statusNotice.value = "يرجى تفعيل البلوتوث من إعدادات الجهاز أولًا."
            return
        }

        _statusNotice.value = null
        registerReceiverIfNeeded()
        startRfcommServerIfNeeded()
        loadPairedDevices()

        if (bluetoothAdapter?.isDiscovering == true) {
            bluetoothAdapter.cancelDiscovery()
        }
        val started = bluetoothAdapter?.startDiscovery() ?: false
        if (started) {
            _connectionState.value =
                if (activeConnections.isNotEmpty()) ConnectionState.CONNECTED else ConnectionState.DISCOVERING
        } else {
            _statusNotice.value = "تعذّر بدء مسح البلوتوث. عرضنا الأجهزة المقترنة المتاحة للاتصال المباشر."
        }
    }

    fun stopDiscoveryOnly() {
        if (hasBluetoothScanPermission() && bluetoothAdapter?.isDiscovering == true) {
            runCatching { bluetoothAdapter.cancelDiscovery() }
        }
        _connectionState.value =
            if (activeConnections.isNotEmpty()) ConnectionState.CONNECTED else ConnectionState.DISCONNECTED
    }

    fun stopAll() {
        stopDiscoveryOnly()
        unregisterReceiverIfNeeded()
        serverAcceptJob?.cancel()
        runCatching { rfcommServerSocket?.close() }
        rfcommServerSocket = null
        activeConnections.keys.toList().forEach { peerId ->
            val conn = activeConnections.remove(peerId)
            runCatching { conn?.socket?.close() }
            conn?.readerJob?.cancel()
        }
        _connectionState.value = ConnectionState.DISCONNECTED
    }

    private fun loadPairedDevices() {
        if (!hasBluetoothConnectPermission()) return
        val bonded = bluetoothAdapter?.bondedDevices ?: emptySet()
        bonded.forEach { device ->
            val address = device.address ?: return@forEach
            val name = device.name?.takeIf { it.isNotBlank() } ?: "جهاز مقترن ($address)"
            val peer = PeerDevice(
                peerId = "bt_$address",
                nickname = name,
                avatarId = (address.hashCode() and 0x7fffffff) % 8,
                transportType = TransportType.BLUETOOTH,
                address = address,
                isConnected = activeConnections.values.any { it.macAddress == address },
                isPaired = true,
                lastSeenTimestamp = System.currentTimeMillis(),
                rssiOrInfo = "مقترن مسبقًا • جاهز للاتصال"
            )
            upsertBtPeer(peer)
        }
    }

    private fun onBluetoothDeviceFound(device: BluetoothDevice, rssi: Int) {
        val address = device.address ?: return
        val name = device.name?.takeIf { it.isNotBlank() } ?: return // Filter unnamed raw BLE beacons
        val isBonded = device.bondState == BluetoothDevice.BOND_BONDED
        val signalLabel = if (rssi != Short.MIN_VALUE.toInt()) "$rssi dBm" else "قريب"
        val peer = PeerDevice(
            peerId = "bt_$address",
            nickname = name,
            avatarId = (address.hashCode() and 0x7fffffff) % 8,
            transportType = TransportType.BLUETOOTH,
            address = address,
            isConnected = activeConnections.values.any { it.macAddress == address },
            isPaired = isBonded,
            lastSeenTimestamp = System.currentTimeMillis(),
            rssiOrInfo = if (isBonded) "مقترن • $signalLabel" else "غير مقترن • $signalLabel"
        )
        upsertBtPeer(peer)
    }

    private fun startRfcommServerIfNeeded() {
        if (rfcommServerSocket != null) return
        serverAcceptJob?.cancel()
        serverAcceptJob = scope.launch {
            try {
                val server = bluetoothAdapter?.listenUsingRfcommWithServiceRecord(SERVICE_NAME, WASL_BT_UUID)
                rfcommServerSocket = server
                while (isActive && server != null) {
                    val socket = server.accept() ?: continue
                    handleConnectedBluetoothSocket(socket)
                }
            } catch (e: IOException) {
                if (isActive) {
                    _statusNotice.value = "توقف خادم البلوتوث المحلي: ${e.localizedMessage ?: ""}"
                }
            }
        }
    }

    fun connectToBluetoothDevice(macAddress: String) {
        if (!hasBluetoothPermissions()) {
            _statusNotice.value = "يرجى منح أذونات البلوتوث للاتصال بالجهاز."
            return
        }
        val device = try {
            bluetoothAdapter?.getRemoteDevice(macAddress)
        } catch (e: IllegalArgumentException) {
            null
        }
        if (device == null) {
            _statusNotice.value = "عنوان البلوتوث غير صالح: $macAddress"
            return
        }

        // Stop discovery before connecting because Bluetooth discovery significantly slows down RFCOMM connection
        if (bluetoothAdapter?.isDiscovering == true) {
            runCatching { bluetoothAdapter.cancelDiscovery() }
        }

        if (device.bondState == BluetoothDevice.BOND_NONE) {
            _statusNotice.value = "جارٍ طلب الاقتران بالجهاز ${device.name ?: macAddress}…"
            val bondStarted = runCatching { device.createBond() }.getOrDefault(false)
            if (bondStarted) return
        }

        scope.launch {
            _connectionState.value = ConnectionState.CONNECTING
            try {
                val socket = device.createRfcommSocketToServiceRecord(WASL_BT_UUID)
                socket.connect()
                handleConnectedBluetoothSocket(socket)
            } catch (e: IOException) {
                _connectionState.value =
                    if (activeConnections.isNotEmpty()) ConnectionState.CONNECTED else ConnectionState.ERROR
                _statusNotice.value =
                    "تعذّر إنشاء قناة بلوتوث مع ${device.name ?: macAddress}. تأكد من فتح الطرف الآخر لتطبيق «وَصْل» وتفعيل وضع البلوتوث لديه."
            }
        }
    }

    private fun handleConnectedBluetoothSocket(socket: BluetoothSocket) {
        val localProfile = getLocalProfile() ?: run {
            runCatching { socket.close() }
            return
        }
        val macAddress = socket.remoteDevice?.address ?: "unknown"
        val input = DataInputStream(BufferedInputStream(socket.inputStream))
        val output = DataOutputStream(BufferedOutputStream(socket.outputStream))

        val readerJob = scope.launch {
            var remotePeerId = "bt_$macAddress"
            try {
                val hello = WirePacket(
                    type = PacketType.HELLO,
                    packetId = UUID.randomUUID().toString(),
                    sessionId = "bt_${localProfile.userId}",
                    senderId = localProfile.userId,
                    senderName = localProfile.nickname,
                    senderAvatarId = localProfile.avatarId,
                    payload = macAddress,
                    timestamp = System.currentTimeMillis()
                )
                FrameCodec.writeFrame(output, hello)

                while (isActive && socket.isConnected) {
                    val packet = FrameCodec.readFrame(input)
                    when (packet.type) {
                        PacketType.HELLO -> {
                            remotePeerId = packet.senderId
                            val conn = ActiveBtConnection(
                                peerId = remotePeerId,
                                macAddress = macAddress,
                                socket = socket,
                                input = input,
                                output = output,
                                readerJob = coroutineContext[Job]!!
                            )
                            activeConnections[remotePeerId] = conn
                            _connectionState.value = ConnectionState.CONNECTED
                            _statusNotice.value = null

                            val updatedPeer = PeerDevice(
                                peerId = remotePeerId,
                                nickname = packet.senderName,
                                avatarId = packet.senderAvatarId,
                                transportType = TransportType.BLUETOOTH,
                                address = macAddress,
                                isConnected = true,
                                isPaired = true,
                                lastSeenTimestamp = System.currentTimeMillis(),
                                rssiOrInfo = "متصل عبر البلوتوث ($macAddress)"
                            )
                            upsertBtPeer(updatedPeer)
                            _incomingPackets.emit(packet)
                        }

                        PacketType.CHAT_MESSAGE -> {
                            val ack = WirePacket(
                                type = PacketType.DELIVERY_ACK,
                                packetId = UUID.randomUUID().toString(),
                                sessionId = packet.sessionId,
                                senderId = localProfile.userId,
                                senderName = localProfile.nickname,
                                senderAvatarId = localProfile.avatarId,
                                payload = "ACK",
                                timestamp = System.currentTimeMillis(),
                                ackTargetMessageId = packet.packetId
                            )
                            runCatching { FrameCodec.writeFrame(output, ack) }
                            _incomingPackets.emit(packet)
                        }

                        PacketType.DELIVERY_ACK -> {
                            _incomingPackets.emit(packet)
                        }

                        PacketType.PING -> {
                            val pong = WirePacket(
                                type = PacketType.PONG,
                                packetId = UUID.randomUUID().toString(),
                                sessionId = packet.sessionId,
                                senderId = localProfile.userId,
                                senderName = localProfile.nickname,
                                senderAvatarId = localProfile.avatarId,
                                payload = "PONG",
                                timestamp = System.currentTimeMillis()
                            )
                            runCatching { FrameCodec.writeFrame(output, pong) }
                        }

                        PacketType.PONG -> {}
                        PacketType.DISCONNECT -> break
                    }
                }
            } catch (e: IOException) {
                // Socket disconnected
            } finally {
                runCatching { socket.close() }
                activeConnections.remove(remotePeerId)
                markBtPeerDisconnected(remotePeerId, macAddress)
                _connectionState.value =
                    if (activeConnections.isNotEmpty()) ConnectionState.CONNECTED else ConnectionState.DISCONNECTED
            }
        }
    }

    suspend fun sendPacketToPeer(peerId: String, packet: WirePacket): Boolean = withContext(Dispatchers.IO) {
        val conn = activeConnections[peerId]
            ?: activeConnections.values.firstOrNull { "bt_${it.macAddress}" == peerId }
            ?: return@withContext false

        return@withContext try {
            FrameCodec.writeFrame(conn.output, packet)
            true
        } catch (e: IOException) {
            activeConnections.remove(conn.peerId)
            runCatching { conn.socket.close() }
            markBtPeerDisconnected(conn.peerId, conn.macAddress)
            false
        }
    }

    fun disconnectPeer(peerId: String) {
        val conn = activeConnections.remove(peerId)
            ?: activeConnections.values.firstOrNull { "bt_${it.macAddress}" == peerId }?.also {
                activeConnections.remove(it.peerId)
            } ?: return

        scope.launch {
            runCatching { conn.socket.close() }
            conn.readerJob.cancel()
            markBtPeerDisconnected(conn.peerId, conn.macAddress)
            _connectionState.value =
                if (activeConnections.isNotEmpty()) ConnectionState.CONNECTED else ConnectionState.DISCONNECTED
        }
    }

    fun isPeerConnected(peerId: String): Boolean {
        val conn = activeConnections[peerId]
            ?: activeConnections.values.firstOrNull { "bt_${it.macAddress}" == peerId }
            ?: return false
        return conn.socket.isConnected
    }

    private fun upsertBtPeer(peer: PeerDevice) {
        _discoveredPeers.update { list ->
            val mutable = list.toMutableList()
            val idx = mutable.indexOfFirst { it.peerId == peer.peerId || it.address == peer.address }
            if (idx >= 0) {
                mutable[idx] = peer
            } else {
                mutable.add(0, peer)
            }
            mutable
        }
    }

    private fun markBtPeerDisconnected(peerId: String, macAddress: String) {
        _discoveredPeers.update { list ->
            list.map {
                if (it.peerId == peerId || it.address == macAddress) it.copy(isConnected = false) else it
            }
        }
    }

    private fun registerReceiverIfNeeded() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.applicationContext.registerReceiver(btDiscoveryReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            context.applicationContext.registerReceiver(btDiscoveryReceiver, filter)
        }
        receiverRegistered = true
    }

    private fun unregisterReceiverIfNeeded() {
        if (!receiverRegistered) return
        runCatching { context.applicationContext.unregisterReceiver(btDiscoveryReceiver) }
        receiverRegistered = false
    }

    companion object {
        const val SERVICE_NAME = "WASL_Local_Chat_RFCOMM"
        val WASL_BT_UUID: UUID = UUID.fromString("8c4e2b90-7a1f-4e92-b15a-9f0e4b6d8a21")
    }
}
