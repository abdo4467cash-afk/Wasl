package com.wasl.chat.viewmodel

import android.app.Application
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wasl.chat.WaslApplication
import com.wasl.chat.bluetooth.BluetoothRfcommManager
import com.wasl.chat.model.ChatMessageEntity
import com.wasl.chat.model.ConnectionState
import com.wasl.chat.model.KnownPeerEntity
import com.wasl.chat.model.MessageStatus
import com.wasl.chat.model.PeerDevice
import com.wasl.chat.model.TransportType
import com.wasl.chat.model.UserProfile
import com.wasl.chat.network.LanDiscoveryAndTransportManager
import com.wasl.chat.protocol.FrameCodec
import com.wasl.chat.protocol.PacketType
import com.wasl.chat.protocol.WirePacket
import com.wasl.chat.service.ConnectionForegroundService
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class WaslViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as WaslApplication
    private val chatDao = app.database.chatDao()
    private val prefs = app.preferencesRepository

    val userProfile: StateFlow<UserProfile?> = prefs.userProfile
    val selectedTransport: StateFlow<TransportType> = prefs.selectedTransport

    val lanManager = LanDiscoveryAndTransportManager(
        context = app.applicationContext,
        getLocalProfile = { userProfile.value }
    )

    val bluetoothManager = BluetoothRfcommManager(
        context = app.applicationContext,
        getLocalProfile = { userProfile.value }
    )

    private val _activePeer = MutableStateFlow<PeerDevice?>(null)
    val activePeer: StateFlow<PeerDevice?> = _activePeer.asStateFlow()

    private val _permissionExplanationBanner = MutableStateFlow<String?>(null)
    val permissionExplanationBanner: StateFlow<String?> = _permissionExplanationBanner.asStateFlow()

    val knownPeersHistory: StateFlow<List<KnownPeerEntity>> =
        chatDao.observeKnownPeers()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentDiscoveredPeers: StateFlow<List<PeerDevice>> =
        combine(
            selectedTransport,
            lanManager.discoveredPeers,
            bluetoothManager.discoveredPeers
        ) { transport, lanList, btList ->
            when (transport) {
                TransportType.WIFI_LAN -> lanList
                TransportType.BLUETOOTH -> btList
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentConnectionState: StateFlow<ConnectionState> =
        combine(
            selectedTransport,
            lanManager.connectionState,
            bluetoothManager.connectionState
        ) { transport, lanState, btState ->
            when (transport) {
                TransportType.WIFI_LAN -> lanState
                TransportType.BLUETOOTH -> btState
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ConnectionState.DISCONNECTED)

    val currentStatusNotice: StateFlow<String?> =
        combine(
            selectedTransport,
            lanManager.statusNotice,
            bluetoothManager.statusNotice,
            _permissionExplanationBanner
        ) { transport, lanNotice, btNotice, permNotice ->
            permNotice ?: when (transport) {
                TransportType.WIFI_LAN -> lanNotice
                TransportType.BLUETOOTH -> btNotice
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeConversationMessages: StateFlow<List<ChatMessageEntity>> =
        _activePeer.flatMapLatest { peer ->
            if (peer == null) flowOf(emptyList())
            else chatDao.observeMessagesForPeer(peer.peerId)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var lastSendClickElapsedMs = 0L

    init {
        observeIncomingPackets()
    }

    private fun observeIncomingPackets() {
        viewModelScope.launch {
            lanManager.incomingPackets.collect { packet ->
                handleIncomingWirePacket(packet, TransportType.WIFI_LAN)
            }
        }
        viewModelScope.launch {
            bluetoothManager.incomingPackets.collect { packet ->
                handleIncomingWirePacket(packet, TransportType.BLUETOOTH)
            }
        }
    }

    private suspend fun handleIncomingWirePacket(packet: WirePacket, transport: TransportType) {
        val myProfile = userProfile.value ?: return
        when (packet.type) {
            PacketType.HELLO -> {
                val peerEntity = KnownPeerEntity(
                    peerId = packet.senderId,
                    nickname = packet.senderName,
                    avatarId = packet.senderAvatarId,
                    lastTransport = transport,
                    lastAddress = packet.payload,
                    lastPort = LanDiscoveryAndTransportManager.DEFAULT_PORT,
                    lastSeenTimestamp = System.currentTimeMillis(),
                    unreadCount = 0,
                    lastMessagePreview = "متصل الآن"
                )
                chatDao.upsertKnownPeer(peerEntity)
                updateForegroundServiceStatus(true, transport.arabicLabel)
                flushFailedMessagesForPeer(packet.senderId, transport)
            }

            PacketType.CHAT_MESSAGE -> {
                val cleanText = packet.payload.trim()
                if (cleanText.isEmpty()) return

                val messageEntity = ChatMessageEntity(
                    messageId = packet.packetId,
                    conversationId = packet.senderId,
                    senderId = packet.senderId,
                    senderName = packet.senderName,
                    senderAvatarId = packet.senderAvatarId,
                    receiverId = myProfile.userId,
                    content = cleanText,
                    timestamp = packet.timestamp,
                    isOutgoing = false,
                    status = MessageStatus.DELIVERED,
                    transportUsed = transport
                )
                val insertedRowId = chatDao.insertMessageIfAbsent(messageEntity)
                if (insertedRowId != -1L) {
                    val isCurrentlyViewing = _activePeer.value?.peerId == packet.senderId
                    val peerEntity = KnownPeerEntity(
                        peerId = packet.senderId,
                        nickname = packet.senderName,
                        avatarId = packet.senderAvatarId,
                        lastTransport = transport,
                        lastAddress = "",
                        lastPort = LanDiscoveryAndTransportManager.DEFAULT_PORT,
                        lastSeenTimestamp = System.currentTimeMillis(),
                        unreadCount = if (isCurrentlyViewing) 0 else 1,
                        lastMessagePreview = cleanText.take(60)
                    )
                    chatDao.upsertKnownPeer(peerEntity)
                }
            }

            PacketType.DELIVERY_ACK -> {
                val ackedId = packet.ackTargetMessageId ?: return
                // Only set DELIVERED when a genuine technical ACK frame arrives from the peer
                chatDao.updateMessageStatus(ackedId, MessageStatus.DELIVERED)
            }

            else -> {}
        }
    }

    fun saveOnboardingProfile(nickname: String, avatarId: Int, customUri: String?) {
        prefs.saveUserProfile(nickname, avatarId, customUri)
        lanManager.refreshLocalIpDisplay()
    }

    fun selectTransport(transportType: TransportType) {
        prefs.setPreferredTransport(transportType)
        _permissionExplanationBanner.value = null
    }

    fun setPermissionExplanation(message: String?) {
        _permissionExplanationBanner.value = message
    }

    fun startDiscoveryForSelectedTransport() {
        _permissionExplanationBanner.value = null
        when (selectedTransport.value) {
            TransportType.WIFI_LAN -> lanManager.startServerAndDiscovery()
            TransportType.BLUETOOTH -> bluetoothManager.startRfcommServerAndDiscovery()
        }
    }

    fun stopDiscoveryForSelectedTransport() {
        when (selectedTransport.value) {
            TransportType.WIFI_LAN -> lanManager.stopDiscoveryOnly()
            TransportType.BLUETOOTH -> bluetoothManager.stopDiscoveryOnly()
        }
    }

    fun connectToPeer(peer: PeerDevice) {
        _activePeer.value = peer
        viewModelScope.launch {
            chatDao.clearUnreadCount(peer.peerId)
        }
        when (peer.transportType) {
            TransportType.WIFI_LAN -> lanManager.connectToDiscoveredPeer(peer)
            TransportType.BLUETOOTH -> bluetoothManager.connectToBluetoothDevice(peer.address)
        }
    }

    fun connectDirectByIp(ipAddress: String, portText: String) {
        val port = portText.toIntOrNull() ?: LanDiscoveryAndTransportManager.DEFAULT_PORT
        lanManager.connectToPeerByIp(ipAddress, port)
    }

    fun openConversationWithPeer(peer: PeerDevice) {
        _activePeer.value = peer
        viewModelScope.launch {
            chatDao.clearUnreadCount(peer.peerId)
        }
        if (!isPeerCurrentlyConnected(peer.peerId)) {
            connectToPeer(peer)
        }
    }

    fun isPeerCurrentlyConnected(peerId: String): Boolean {
        return lanManager.isPeerConnected(peerId) || bluetoothManager.isPeerConnected(peerId)
    }

    /**
     * Sends a message with:
     * - Empty/blank input rejection
     * - Rapid double-tap debounce (280ms)
     * - Automatic chunking or safe cap up to 4000 characters
     * - Immediate local Room persistence with status SENDING -> SENT -> DELIVERED (on ACK) or FAILED
     */
    fun sendChatMessage(rawText: String) {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) return

        val nowElapsed = SystemClock.elapsedRealtime()
        if (nowElapsed - lastSendClickElapsedMs < 280L) {
            return // Prevent accidental duplicate sends on rapid taps
        }
        lastSendClickElapsedMs = nowElapsed

        val me = userProfile.value ?: return
        val targetPeer = _activePeer.value ?: return
        val safeContent = trimmed.take(FrameCodec.MAX_MESSAGE_CHARS)
        val messageId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()

        val entity = ChatMessageEntity(
            messageId = messageId,
            conversationId = targetPeer.peerId,
            senderId = me.userId,
            senderName = me.nickname,
            senderAvatarId = me.avatarId,
            receiverId = targetPeer.peerId,
            content = safeContent,
            timestamp = now,
            isOutgoing = true,
            status = MessageStatus.SENDING,
            transportUsed = targetPeer.transportType
        )

        viewModelScope.launch {
            chatDao.insertMessageIfAbsent(entity)
            dispatchMessageOverWire(entity, targetPeer)
        }
    }

    fun retryFailedMessage(message: ChatMessageEntity) {
        val targetPeer = _activePeer.value ?: return
        viewModelScope.launch {
            chatDao.updateMessageStatus(message.messageId, MessageStatus.SENDING)
            dispatchMessageOverWire(message, targetPeer)
        }
    }

    private suspend fun dispatchMessageOverWire(message: ChatMessageEntity, targetPeer: PeerDevice) {
        val packet = WirePacket(
            type = PacketType.CHAT_MESSAGE,
            packetId = message.messageId, // Reuse original UUID so recipient deduplicates
            sessionId = "chat_${message.senderId}_${targetPeer.peerId}",
            senderId = message.senderId,
            senderName = message.senderName,
            senderAvatarId = message.senderAvatarId,
            payload = message.content,
            timestamp = message.timestamp
        )

        val sentOk = when {
            lanManager.isPeerConnected(targetPeer.peerId) ->
                lanManager.sendPacketToPeer(targetPeer.peerId, packet)
            bluetoothManager.isPeerConnected(targetPeer.peerId) ->
                bluetoothManager.sendPacketToPeer(targetPeer.peerId, packet)
            else -> false
        }

        if (sentOk) {
            // Marked SENT when written to socket; upgraded to DELIVERED only when DELIVERY_ACK arrives
            chatDao.updateMessageStatus(message.messageId, MessageStatus.SENT)
        } else {
            chatDao.updateMessageStatus(message.messageId, MessageStatus.FAILED)
        }
    }

    private suspend fun flushFailedMessagesForPeer(peerId: String, transport: TransportType) {
        val failedList = chatDao.getFailedMessagesForPeer(peerId)
        if (failedList.isEmpty()) return
        val dummyPeer = PeerDevice(
            peerId = peerId,
            nickname = "",
            avatarId = 0,
            transportType = transport,
            address = ""
        )
        for (msg in failedList) {
            dispatchMessageOverWire(msg, dummyPeer)
        }
    }

    fun disconnectCurrentPeer() {
        val peer = _activePeer.value ?: return
        lanManager.disconnectPeer(peer.peerId)
        bluetoothManager.disconnectPeer(peer.peerId)
        updateForegroundServiceStatus(false, "")
    }

    fun disconnectAllTransports() {
        lanManager.stopAll()
        bluetoothManager.stopAll()
        updateForegroundServiceStatus(false, "")
    }

    fun clearAllLocalHistory() {
        viewModelScope.launch {
            chatDao.deleteAllMessages()
            chatDao.deleteAllPeers()
        }
    }

    private fun updateForegroundServiceStatus(active: Boolean, label: String) {
        runCatching {
            val intent = Intent(app.applicationContext, ConnectionForegroundService::class.java).apply {
                action = if (active) ConnectionForegroundService.ACTION_START else ConnectionForegroundService.ACTION_STOP
                putExtra(ConnectionForegroundService.EXTRA_TRANSPORT_LABEL, label)
            }
            if (active && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                app.applicationContext.startForegroundService(intent)
            } else {
                app.applicationContext.startService(intent)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        lanManager.stopAll()
        bluetoothManager.stopAll()
    }
}
