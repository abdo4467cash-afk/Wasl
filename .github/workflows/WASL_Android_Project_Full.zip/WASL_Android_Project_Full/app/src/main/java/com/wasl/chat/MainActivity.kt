package com.wasl.chat

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.wasl.chat.model.TransportType
import com.wasl.chat.ui.screens.ChatScreen
import com.wasl.chat.ui.screens.ConnectionManagementScreen
import com.wasl.chat.ui.screens.DiscoveryScreen
import com.wasl.chat.ui.screens.HomeScreen
import com.wasl.chat.ui.screens.OnboardingScreen
import com.wasl.chat.ui.screens.ProfileSettingsScreen
import com.wasl.chat.ui.theme.WaslColors
import com.wasl.chat.ui.theme.WaslTheme
import com.wasl.chat.viewmodel.WaslViewModel

enum class WaslScreenDestination {
    ONBOARDING,
    HOME,
    DISCOVERY,
    CHAT,
    CONNECTION_MANAGEMENT,
    PROFILE_SETTINGS
}

class MainActivity : ComponentActivity() {
    private val viewModel: WaslViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WaslTheme(rtlByDefault = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = WaslColors.WarmIvoryBackground
                ) {
                    WaslMainNavigationHost(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
private fun WaslMainNavigationHost(viewModel: WaslViewModel) {
    val userProfile by viewModel.userProfile.collectAsState()
    val selectedTransport by viewModel.selectedTransport.collectAsState()
    val connectionState by viewModel.currentConnectionState.collectAsState()
    val discoveredPeers by viewModel.currentDiscoveredPeers.collectAsState()
    val knownPeersHistory by viewModel.knownPeersHistory.collectAsState()
    val statusNotice by viewModel.currentStatusNotice.collectAsState()
    val activePeer by viewModel.activePeer.collectAsState()
    val messages by viewModel.activeConversationMessages.collectAsState()
    val localIpAndPort by viewModel.lanManager.localIpAndPort.collectAsState()

    var currentDestination by rememberSaveable {
        mutableStateOf(
            if (userProfile == null) WaslScreenDestination.ONBOARDING
            else WaslScreenDestination.HOME
        )
    }

    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val deniedAny = results.entries.any { !it.value }
        if (deniedAny) {
            viewModel.setPermissionExplanation(
                "تم رفض بعض أذونات الاتصال القريب. لن يتمكن التطبيق من البحث التلقائي عبر البلوتوث دون منح الإذن، لكن ما يزال بإمكانك استخدام شبكة Wi-Fi المحلية."
            )
        } else {
            viewModel.setPermissionExplanation(null)
            viewModel.startDiscoveryForSelectedTransport()
        }
    }

    fun requestNecessaryPermissionsAndStart() {
        val perms = buildRequiredPermissionsList(selectedTransport)
        if (perms.isEmpty()) {
            viewModel.startDiscoveryForSelectedTransport()
        } else {
            permissionsLauncher.launch(perms.toTypedArray())
        }
    }

    LaunchedEffect(userProfile != null) {
        if (userProfile != null && currentDestination == WaslScreenDestination.ONBOARDING) {
            currentDestination = WaslScreenDestination.HOME
            requestNecessaryPermissionsAndStart()
        }
    }

    // Subtle, calm editorial screen transitions (220ms Crossfade, respects accessibility reduced motion)
    Crossfade(
        targetState = currentDestination,
        animationSpec = tween(durationMillis = 220),
        label = "wasl_editorial_navigation"
    ) { screen ->
        when (screen) {
            WaslScreenDestination.ONBOARDING -> {
                OnboardingScreen(
                    onCompleteOnboarding = { nickname, avatarId, customUri ->
                        viewModel.saveOnboardingProfile(nickname, avatarId, customUri)
                        currentDestination = WaslScreenDestination.HOME
                        requestNecessaryPermissionsAndStart()
                    }
                )
            }

            WaslScreenDestination.HOME -> {
                val profile = userProfile ?: return@Crossfade
                HomeScreen(
                    userProfile = profile,
                    selectedTransport = selectedTransport,
                    connectionState = connectionState,
                    discoveredPeers = discoveredPeers,
                    knownPeersHistory = knownPeersHistory,
                    statusNotice = statusNotice,
                    onSelectTransport = { transport ->
                        viewModel.selectTransport(transport)
                        requestNecessaryPermissionsAndStart()
                    },
                    onStartDiscoveryScreen = {
                        currentDestination = WaslScreenDestination.DISCOVERY
                        requestNecessaryPermissionsAndStart()
                    },
                    onOpenPeerChat = { peer ->
                        viewModel.openConversationWithPeer(peer)
                        currentDestination = WaslScreenDestination.CHAT
                    },
                    onOpenConnectionManagement = {
                        currentDestination = WaslScreenDestination.CONNECTION_MANAGEMENT
                    },
                    onOpenProfileSettings = {
                        currentDestination = WaslScreenDestination.PROFILE_SETTINGS
                    },
                    onDismissNotice = {
                        viewModel.setPermissionExplanation(null)
                    }
                )
            }

            WaslScreenDestination.DISCOVERY -> {
                DiscoveryScreen(
                    selectedTransport = selectedTransport,
                    connectionState = connectionState,
                    discoveredPeers = discoveredPeers,
                    localIpAndPort = localIpAndPort,
                    statusNotice = statusNotice,
                    onSelectTransport = { transport ->
                        viewModel.selectTransport(transport)
                        requestNecessaryPermissionsAndStart()
                    },
                    onStartDiscovery = {
                        requestNecessaryPermissionsAndStart()
                    },
                    onStopDiscovery = {
                        viewModel.stopDiscoveryForSelectedTransport()
                    },
                    onConnectPeer = { peer ->
                        viewModel.openConversationWithPeer(peer)
                        currentDestination = WaslScreenDestination.CHAT
                    },
                    onNavigateBack = {
                        currentDestination = WaslScreenDestination.HOME
                    }
                )
            }

            WaslScreenDestination.CHAT -> {
                val peer = activePeer
                if (peer == null) {
                    currentDestination = WaslScreenDestination.HOME
                } else {
                    val isLive = viewModel.isPeerCurrentlyConnected(peer.peerId)
                    ChatScreen(
                        peer = peer,
                        isPeerLiveConnected = isLive,
                        messages = messages,
                        onSendMessage = { text -> viewModel.sendChatMessage(text) },
                        onRetryFailedMessage = { msg -> viewModel.retryFailedMessage(msg) },
                        onReconnectPeer = { viewModel.connectToPeer(peer) },
                        onNavigateBack = { currentDestination = WaslScreenDestination.HOME }
                    )
                }
            }

            WaslScreenDestination.CONNECTION_MANAGEMENT -> {
                ConnectionManagementScreen(
                    selectedTransport = selectedTransport,
                    connectionState = connectionState,
                    localIpAndPort = localIpAndPort,
                    activePeer = activePeer,
                    onSelectTransport = { transport ->
                        viewModel.selectTransport(transport)
                        requestNecessaryPermissionsAndStart()
                    },
                    onConnectDirectByIp = { ip, port ->
                        viewModel.connectDirectByIp(ip, port)
                    },
                    onReconnectCurrentTransport = {
                        requestNecessaryPermissionsAndStart()
                    },
                    onDisconnectAll = {
                        viewModel.disconnectAllTransports()
                    },
                    onNavigateBack = {
                        currentDestination = WaslScreenDestination.HOME
                    }
                )
            }

            WaslScreenDestination.PROFILE_SETTINGS -> {
                val profile = userProfile ?: return@Crossfade
                ProfileSettingsScreen(
                    userProfile = profile,
                    onSaveProfile = { newName, newAvatar ->
                        viewModel.saveOnboardingProfile(newName, newAvatar, profile.customAvatarUri)
                    },
                    onRequestPermissionsAgain = {
                        requestNecessaryPermissionsAndStart()
                    },
                    onClearLocalHistory = {
                        viewModel.clearAllLocalHistory()
                    },
                    onNavigateBack = {
                        currentDestination = WaslScreenDestination.HOME
                    }
                )
            }
        }
    }
}

private fun buildRequiredPermissionsList(transportType: TransportType): List<String> {
    val list = mutableListOf<String>()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        list.add(Manifest.permission.POST_NOTIFICATIONS)
        if (transportType == TransportType.WIFI_LAN) {
            list.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
    }
    if (transportType == TransportType.BLUETOOTH) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
            list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
        } else {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }
    return list
}
