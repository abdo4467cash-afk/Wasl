package com.wasl.chat

import android.app.Application
import com.wasl.chat.data.UserPreferencesRepository
import com.wasl.chat.data.WaslDatabase

class WaslApplication : Application() {
    lateinit var database: WaslDatabase
        private set
    lateinit var preferencesRepository: UserPreferencesRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = WaslDatabase.getInstance(this)
        preferencesRepository = UserPreferencesRepository(this)
    }
}
