package com.wasl.chat

import com.wasl.chat.protocol.FrameCodec
import com.wasl.chat.protocol.PacketType
import com.wasl.chat.protocol.WirePacket
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class ProtocolAndFramingTest {

    @Test
    fun testLengthPrefixedMultiFrameStreamWithoutMerging() {
        val baos = ByteArrayOutputStream()
        val out = DataOutputStream(baos)

        val msg1 = WirePacket(
            type = PacketType.CHAT_MESSAGE,
            packetId = UUID.randomUUID().toString(),
            sessionId = "session_1",
            senderId = "wasl_peer_a",
            senderName = "ليلى",
            senderAvatarId = 0,
            payload = "السلام عليكم! هذه رسالة أولى عبر الشبكة المحلية.",
            timestamp = 1700000001000L
        )

        val msg2 = WirePacket(
            type = PacketType.CHAT_MESSAGE,
            packetId = UUID.randomUUID().toString(),
            sessionId = "session_1",
            senderId = "wasl_peer_a",
            senderName = "ليلى",
            senderAvatarId = 0,
            payload = "وهذه رسالة ثانية طويلة مباشرة بعدها للتأكد من عدم دمج الرسائل في التدفق الشبكي. ".repeat(15),
            timestamp = 1700000002000L
        )

        FrameCodec.writeFrame(out, msg1)
        FrameCodec.writeFrame(out, msg2)

        val bais = ByteArrayInputStream(baos.toByteArray())
        val input = DataInputStream(bais)

        val decoded1 = FrameCodec.readFrame(input)
        val decoded2 = FrameCodec.readFrame(input)

        assertEquals(msg1.packetId, decoded1.packetId)
        assertEquals(msg1.payload, decoded1.payload)
        assertEquals(msg2.packetId, decoded2.packetId)
        assertEquals(msg2.payload, decoded2.payload)
    }

    @Test
    fun testTwoPeerSocketBidirectionalExchangeAndDeliveryAck() {
        val serverLatch = CountDownLatch(1)
        val ackLatch = CountDownLatch(1)
        var receivedAckForId: String? = null

        val serverSocket = ServerSocket(0)
        val port = serverSocket.localPort

        val serverThread = Thread {
            val client = serverSocket.accept()
            val input = DataInputStream(client.getInputStream())
            val output = DataOutputStream(client.getOutputStream())

            val incoming = FrameCodec.readFrame(input)
            if (incoming.type == PacketType.CHAT_MESSAGE) {
                val ack = WirePacket(
                    type = PacketType.DELIVERY_ACK,
                    packetId = UUID.randomUUID().toString(),
                    sessionId = incoming.sessionId,
                    senderId = "wasl_peer_b",
                    senderName = "طارق",
                    senderAvatarId = 2,
                    payload = "ACK",
                    timestamp = System.currentTimeMillis(),
                    ackTargetMessageId = incoming.packetId
                )
                FrameCodec.writeFrame(output, ack)
                serverLatch.countDown()
            }
            client.close()
            serverSocket.close()
        }
        serverThread.start()

        val clientSocket = Socket("127.0.0.1", port)
        val clientOut = DataOutputStream(clientSocket.getOutputStream())
        val clientIn = DataInputStream(clientSocket.getInputStream())

        val sentMessageId = UUID.randomUUID().toString()
        val outgoing = WirePacket(
            type = PacketType.CHAT_MESSAGE,
            packetId = sentMessageId,
            sessionId = "session_ab",
            senderId = "wasl_peer_a",
            senderName = "ليلى",
            senderAvatarId = 0,
            payload = "مرحبًا طارق، هل تسمعني بدون إنترنت؟",
            timestamp = System.currentTimeMillis()
        )
        FrameCodec.writeFrame(clientOut, outgoing)

        val ackPacket = FrameCodec.readFrame(clientIn)
        if (ackPacket.type == PacketType.DELIVERY_ACK) {
            receivedAckForId = ackPacket.ackTargetMessageId
            ackLatch.countDown()
        }
        clientSocket.close()

        serverLatch.await(3, TimeUnit.SECONDS)
        ackLatch.await(3, TimeUnit.SECONDS)
        assertNotNull(receivedAckForId)
        assertEquals(sentMessageId, receivedAckForId)
    }
}
