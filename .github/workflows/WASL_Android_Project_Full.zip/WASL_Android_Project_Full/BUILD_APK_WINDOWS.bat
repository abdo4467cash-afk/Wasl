@echo off
chcp 65001 >nul
title بناء تطبيق وَصْل | WASL APK تلقائياً بدون Android Studio
echo ====================================================================
echo   بناء تطبيق وَصْل (WASL) واستخراج ملف APK تلقائياً (بدون Android Studio)
echo ====================================================================
echo.

where java >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] يرجى تثبيت Java JDK 17 أولاً من الرابط:
    echo     https://adoptium.net/temurin/releases/?version=17
    pause
    exit /b 1
)

if exist "app\build.gradle.kts" (
    set PROJ_DIR=.
) else if exist "WASL-Android\app\build.gradle.kts" (
    cd WASL-Android
)

echo [*] جاري التحقق من أداة البناء السريعة Gradle...
if not exist ".gradle-portable\gradle-8.6\bin\gradle.bat" (
    echo [*] جاري تحميل أداة البناء الخفيفة Gradle 8.6 تلقائياً ^(حوالي 130 ميجابايت فقط بدلاً من 10 جيجابايت^)...
    mkdir ".gradle-portable" 2>nul
    powershell -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.6-bin.zip' -OutFile '.gradle-portable\gradle.zip'"
    powershell -Command "Expand-Archive -Path '.gradle-portable\gradle.zip' -DestinationPath '.gradle-portable' -Force"
)

echo [*] جاري بناء ملف WASL-v1.0.0.apk ...
call ".gradle-portable\gradle-8.6\bin\gradle.bat" assembleDebug

if exist "app\build\outputs\apk\debug\app-debug.apk" (
    copy /Y "app\build\outputs\apk\debug\app-debug.apk" "WASL-v1.0.0.apk" >nul
    echo.
    echo ====================================================================
    echo   [تم بنجاح!] تم استخراج ملف التطبيق الجاهز للتثبيت:
    echo   %cd%\WASL-v1.0.0.apk
    echo ====================================================================
    explorer.exe /select,"%cd%\WASL-v1.0.0.apk"
) else (
    echo [!] تعذّر إكمال البناء التلقائي. تأكد من وجود اتصال بالإنترنت ومفتاح ANDROID_HOME، أو استخدم طريقة GitHub السحابية الأسرع.
)
pause
