package com.wasl.chat.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.wasl.chat.model.ChatMessageEntity
import com.wasl.chat.model.KnownPeerEntity
import com.wasl.chat.model.MessageStatus
import com.wasl.chat.model.TransportType
import kotlinx.coroutines.flow.Flow

class WaslTypeConverters {
    @TypeConverter
    fun fromMessageStatus(status: MessageStatus): String = status.name

    @TypeConverter
    fun toMessageStatus(value: String): MessageStatus =
        runCatching { MessageStatus.valueOf(value) }.getOrDefault(MessageStatus.SENT)

    @TypeConverter
    fun fromTransportType(type: TransportType): String = type.name

    @TypeConverter
    fun toTransportType(value: String): TransportType =
        runCatching { TransportType.valueOf(value) }.getOrDefault(TransportType.WIFI_LAN)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM messages WHERE conversationId = :peerId ORDER BY timestamp ASC")
    fun observeMessagesForPeer(peerId: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM messages WHERE messageId = :messageId LIMIT 1")
    suspend fun getMessageById(messageId: String): ChatMessageEntity?

    /**
     * OnConflictStrategy.IGNORE guarantees that duplicate retransmissions
     * with the same UUID are never inserted or shown twice.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessageIfAbsent(message: ChatMessageEntity): Long

    @Query("UPDATE messages SET status = :status WHERE messageId = :messageId")
    suspend fun updateMessageStatus(messageId: String, status: MessageStatus)

    @Query("SELECT * FROM messages WHERE conversationId = :peerId AND isOutgoing = 1 AND status = 'FAILED' ORDER BY timestamp ASC")
    suspend fun getFailedMessagesForPeer(peerId: String): List<ChatMessageEntity>

    @Query("SELECT * FROM peers ORDER BY lastSeenTimestamp DESC")
    fun observeKnownPeers(): Flow<List<KnownPeerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertKnownPeer(peer: KnownPeerEntity)

    @Query("UPDATE peers SET unreadCount = 0 WHERE peerId = :peerId")
    suspend fun clearUnreadCount(peerId: String)

    @Query("DELETE FROM messages")
    suspend fun deleteAllMessages()

    @Query("DELETE FROM peers")
    suspend fun deleteAllPeers()
}

@Database(
    entities = [ChatMessageEntity::class, KnownPeerEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(WaslTypeConverters::class)
abstract class WaslDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile
        private var INSTANCE: WaslDatabase? = null

        fun getInstance(context: Context): WaslDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WaslDatabase::class.java,
                    "wasl_local_chat.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
