package com.wasl.chat.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Warm Editorial Minimalism — Minimal Luxury Color Palette
 * Strictly light, natural, tactile tones. No cold blues, no neon, no dark-mode-by-default.
 */
object WaslColors {
    val WarmIvoryBackground = Color(0xFFF6F3EB)
    val ElevatedCardSurface = Color(0xFFFFFEFA)
    val SoftLinenSurface = Color(0xFFEFECE2)
    val DeepOlivePrimary = Color(0xFF526247)
    val DeepOliveDark = Color(0xFF3E4B35)
    val SageSecondary = Color(0xFFA9B39A)
    val SageTintSurface = Color(0xFFE9EDE3)
    val WarmCharcoalText = Color(0xFF292B25)
    val OliveGraySubtext = Color(0xFF77796F)
    val CalmBeigeBorder = Color(0xFFE5E0D5)
    val TerracottaAccent = Color(0xFFBD715B)
    val TerracottaSoftBg = Color(0xFFF7EAE5)
    val OutgoingBubbleBg = Color(0xFF526247)
    val OutgoingBubbleText = Color(0xFFFFFEFA)
    val IncomingBubbleBg = Color(0xFFFFFEFA)
    val IncomingBubbleText = Color(0xFF292B25)
}

private val WaslEditorialColorScheme = lightColorScheme(
    primary = WaslColors.DeepOlivePrimary,
    onPrimary = WaslColors.ElevatedCardSurface,
    primaryContainer = WaslColors.SageTintSurface,
    onPrimaryContainer = WaslColors.DeepOliveDark,
    secondary = WaslColors.SageSecondary,
    onSecondary = WaslColors.WarmCharcoalText,
    tertiary = WaslColors.TerracottaAccent,
    onTertiary = WaslColors.ElevatedCardSurface,
    background = WaslColors.WarmIvoryBackground,
    onBackground = WaslColors.WarmCharcoalText,
    surface = WaslColors.ElevatedCardSurface,
    onSurface = WaslColors.WarmCharcoalText,
    surfaceVariant = WaslColors.SoftLinenSurface,
    onSurfaceVariant = WaslColors.OliveGraySubtext,
    outline = WaslColors.CalmBeigeBorder,
    error = WaslColors.TerracottaAccent,
    onError = WaslColors.ElevatedCardSurface
)

val WaslEditorialTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        lineHeight = 40.sp,
        color = WaslColors.WarmCharcoalText
    ),
    headlineLarge = TextStyle(
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 26.sp,
        lineHeight = 34.sp,
        color = WaslColors.WarmCharcoalText
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 21.sp,
        lineHeight = 28.sp,
        color = WaslColors.WarmCharcoalText
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 25.sp,
        color = WaslColors.WarmCharcoalText
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 23.sp,
        color = WaslColors.WarmCharcoalText
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        color = WaslColors.WarmCharcoalText
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 21.sp,
        color = WaslColors.OliveGraySubtext
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        color = WaslColors.WarmCharcoalText
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        color = WaslColors.OliveGraySubtext
    )
)

val WaslShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

@Composable
fun WaslTheme(
    rtlByDefault: Boolean = true,
    content: @Composable () -> Unit
) {
    val direction = if (rtlByDefault) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        MaterialTheme(
            colorScheme = WaslEditorialColorScheme,
            typography = WaslEditorialTypography,
            shapes = WaslShapes,
            content = content
        )
    }
}
