package com.wasl.chat.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.wasl.chat.ui.theme.WaslColors

data class EditorialAvatarSpec(
    val id: Int,
    val arabicTitle: String,
    val backgroundHex: Color,
    val primaryInk: Color,
    val accentInk: Color
)

object WaslAvatarCatalog {
    val avatars = listOf(
        EditorialAvatarSpec(0, "غصن الزيتون", Color(0xFFE9EDE3), Color(0xFF526247), Color(0xFFA9B39A)),
        EditorialAvatarSpec(1, "شمس الطين", Color(0xFFF5E6DF), Color(0xFFBD715B), Color(0xFF526247)),
        EditorialAvatarSpec(2, "قوس الرمال", Color(0xFFEEE8DA), Color(0xFF6B5E4C), Color(0xFFBD715B)),
        EditorialAvatarSpec(3, "نجمة البادية", Color(0xFFE6EBE4), Color(0xFF3E4B35), Color(0xFFC2846E)),
        EditorialAvatarSpec(4, "موجة المريمية", Color(0xFFEDF0E8), Color(0xFF526247), Color(0xFF77796F)),
        EditorialAvatarSpec(5, "هلال الفخار", Color(0xFFF3E9E2), Color(0xFF9C5945), Color(0xFFA9B39A)),
        EditorialAvatarSpec(6, "أفق الكتان", Color(0xFFEBE7DC), Color(0xFF4A4D43), Color(0xFF526247)),
        EditorialAvatarSpec(7, "زهرة الحجر", Color(0xFFEFECE4), Color(0xFF526247), Color(0xFFBD715B))
    )

    fun getSpec(id: Int): EditorialAvatarSpec = avatars[id.coerceIn(0, avatars.lastIndex)]
}

/**
 * Renders an original, offline-embedded botanical/geometric editorial portrait avatar
 * suitable for warm light backgrounds and crisp at both 36dp and 88dp sizes.
 */
@Composable
fun WaslAvatarBadge(
    avatarId: Int,
    size: Dp = 52.dp,
    isSelected: Boolean = false,
    isOnline: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val spec = WaslAvatarCatalog.getSpec(avatarId)
    val borderColor = if (isSelected) WaslColors.DeepOlivePrimary else WaslColors.CalmBeigeBorder
    val borderWidth = if (isSelected) 2.2.dp else 1.dp

    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(spec.backgroundHex)
            .border(borderWidth, borderColor, CircleShape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val cx = w / 2f
            val cy = h / 2f

            when (spec.id % 8) {
                0 -> {
                    // Botanical Olive Leaf & Warm Sun Dot
                    drawCircle(
                        color = spec.accentInk.copy(alpha = 0.45f),
                        radius = w * 0.26f,
                        center = Offset(cx * 1.15f, cy * 0.8f)
                    )
                    val path = Path().apply {
                        moveTo(cx * 0.55f, h * 0.78f)
                        quadraticBezierTo(cx * 0.95f, h * 0.45f, cx * 1.35f, h * 0.25f)
                    }
                    drawPath(path, color = spec.primaryInk, style = Stroke(width = w * 0.055f, cap = StrokeCap.Round))
                    drawCircle(color = spec.primaryInk, radius = w * 0.09f, center = Offset(cx * 0.85f, cy * 0.95f))
                    drawCircle(color = spec.primaryInk, radius = w * 0.08f, center = Offset(cx * 1.12f, cy * 0.72f))
                }
                1 -> {
                    // Terracotta Sun & Editorial Horizon
                    drawCircle(
                        color = spec.primaryInk,
                        radius = w * 0.22f,
                        center = Offset(cx, cy * 0.82f)
                    )
                    drawArc(
                        color = spec.accentInk,
                        startAngle = 15f,
                        sweepAngle = 150f,
                        useCenter = false,
                        topLeft = Offset(w * 0.2f, h * 0.45f),
                        size = Size(w * 0.6f, h * 0.38f),
                        style = Stroke(width = w * 0.055f, cap = StrokeCap.Round)
                    )
                }
                2 -> {
                    // Architectural Desert Arch
                    val archPath = Path().apply {
                        moveTo(w * 0.30f, h * 0.78f)
                        lineTo(w * 0.30f, h * 0.48f)
                        quadraticBezierTo(cx, h * 0.22f, w * 0.70f, h * 0.48f)
                        lineTo(w * 0.70f, h * 0.78f)
                    }
                    drawPath(archPath, color = spec.primaryInk, style = Stroke(width = w * 0.055f, cap = StrokeCap.Round))
                    drawCircle(color = spec.accentInk, radius = w * 0.09f, center = Offset(cx, h * 0.54f))
                }
                3 -> {
                    // Compass Star of Proximity
                    drawLine(
                        color = spec.primaryInk,
                        start = Offset(cx, h * 0.22f),
                        end = Offset(cx, h * 0.78f),
                        strokeWidth = w * 0.05f,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = spec.primaryInk,
                        start = Offset(w * 0.22f, cy),
                        end = Offset(w * 0.78f, cy),
                        strokeWidth = w * 0.05f,
                        cap = StrokeCap.Round
                    )
                    drawCircle(color = spec.accentInk, radius = w * 0.12f, center = Offset(cx, cy))
                }
                4 -> {
                    // Interlocking Wasl Rings
                    drawCircle(
                        color = spec.primaryInk,
                        radius = w * 0.19f,
                        center = Offset(cx * 0.82f, cy),
                        style = Stroke(width = w * 0.05f)
                    )
                    drawCircle(
                        color = spec.accentInk,
                        radius = w * 0.19f,
                        center = Offset(cx * 1.18f, cy),
                        style = Stroke(width = w * 0.05f)
                    )
                }
                5 -> {
                    // Ceramic Crescent & Seed
                    drawArc(
                        color = spec.primaryInk,
                        startAngle = 45f,
                        sweepAngle = 240f,
                        useCenter = false,
                        topLeft = Offset(w * 0.25f, h * 0.25f),
                        size = Size(w * 0.5f, h * 0.5f),
                        style = Stroke(width = w * 0.06f, cap = StrokeCap.Round)
                    )
                    drawCircle(color = spec.accentInk, radius = w * 0.08f, center = Offset(cx * 1.18f, cy * 0.85f))
                }
                6 -> {
                    // Minimalist Portrait Silhouette
                    drawCircle(
                        color = spec.primaryInk,
                        radius = w * 0.14f,
                        center = Offset(cx, h * 0.38f)
                    )
                    drawArc(
                        color = spec.accentInk,
                        startAngle = 200f,
                        sweepAngle = 140f,
                        useCenter = false,
                        topLeft = Offset(w * 0.24f, h * 0.56f),
                        size = Size(w * 0.52f, h * 0.42f),
                        style = Stroke(width = w * 0.065f, cap = StrokeCap.Round)
                    )
                }
                else -> {
                    // Geometric Lotus / Stone Flower
                    drawCircle(
                        color = spec.accentInk.copy(alpha = 0.35f),
                        radius = w * 0.25f,
                        center = Offset(cx, cy)
                    )
                    drawCircle(
                        color = spec.primaryInk,
                        radius = w * 0.16f,
                        center = Offset(cx, cy),
                        style = Stroke(width = w * 0.05f)
                    )
                    drawCircle(color = spec.primaryInk, radius = w * 0.05f, center = Offset(cx, cy))
                }
            }
        }

        if (isOnline) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(size * 0.26f)
                    .clip(CircleShape)
                    .background(WaslColors.DeepOlivePrimary)
                    .border(2.dp, WaslColors.ElevatedCardSurface, CircleShape)
            )
        }
    }
}

/**
 * Calm, non-battery-draining editorial illustration for empty states & discovery radar.
 */
@Composable
fun EditorialDiscoveryIllustration(
    isScanning: Boolean,
    modifier: Modifier = Modifier.size(132.dp)
) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        // Outer soft linen ring
        drawCircle(
            color = WaslColors.CalmBeigeBorder,
            radius = size.minDimension * 0.46f,
            center = Offset(cx, cy),
            style = Stroke(width = 1.5.dp.toPx())
        )
        // Middle sage ring
        drawCircle(
            color = WaslColors.SageSecondary.copy(alpha = if (isScanning) 0.75f else 0.4f),
            radius = size.minDimension * 0.31f,
            center = Offset(cx, cy),
            style = Stroke(width = 2.dp.toPx())
        )
        // Inner warm surface
        drawCircle(
            color = WaslColors.SageTintSurface,
            radius = size.minDimension * 0.18f,
            center = Offset(cx, cy)
        )
        // Center olive node
        drawCircle(
            color = WaslColors.DeepOlivePrimary,
            radius = size.minDimension * 0.06f,
            center = Offset(cx, cy)
        )
        // Terracotta satellite node
        drawCircle(
            color = WaslColors.TerracottaAccent,
            radius = size.minDimension * 0.045f,
            center = Offset(cx + size.minDimension * 0.22f, cy - size.minDimension * 0.21f)
        )
    }
}
