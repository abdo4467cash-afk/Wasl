package com.wasl.chat.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wasl.chat.ui.components.WaslAvatarBadge
import com.wasl.chat.ui.components.WaslAvatarCatalog
import com.wasl.chat.ui.components.WaslPrimaryButton
import com.wasl.chat.ui.components.WaslSecondaryButton
import com.wasl.chat.ui.theme.WaslColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    initialNickname: String = "",
    initialAvatarId: Int = 0,
    onCompleteOnboarding: (nickname: String, avatarId: Int, customUri: String?) -> Unit
) {
    var nickname by rememberSaveable { mutableStateOf(initialNickname) }
    var selectedAvatarId by rememberSaveable { mutableIntStateOf(initialAvatarId) }
    var customPhotoUri by rememberSaveable { mutableStateOf<String?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            customPhotoUri = uri.toString()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WaslColors.WarmIvoryBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.Start
    ) {
        // Editorial Minimalist Brand Mark
        Surface(
            shape = RoundedCornerShape(50),
            color = WaslColors.SageTintSurface,
            border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder)
        ) {
            Text(
                text = "وَصْل • WASL",
                style = MaterialTheme.typography.labelLarge.copy(
                    color = WaslColors.DeepOlivePrimary,
                    fontWeight = FontWeight.SemiBold
                ),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "محادثة قريبة، دافئة، ومباشرة دون إنترنت.",
            style = MaterialTheme.typography.displayLarge
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "تواصل مع الأشخاص من حولك عبر شبكة Wi-Fi المحلية أو البلوتوث المباشر دون الحاجة إلى رقم هاتف أو بريد إلكتروني أو حساب سحابي.",
            style = MaterialTheme.typography.bodyLarge.copy(color = WaslColors.OliveGraySubtext)
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Main Editorial Setup Card
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = WaslColors.ElevatedCardSurface,
            border = BorderStroke(1.dp, WaslColors.CalmBeigeBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "١. الاسم المستعار",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = nickname,
                    onValueChange = { if (it.length <= 32) nickname = it },
                    placeholder = {
                        Text(
                            text = "اكتب اسمك كما يظهر للقريبين منك…",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = WaslColors.DeepOlivePrimary,
                        unfocusedBorderColor = WaslColors.CalmBeigeBorder,
                        focusedContainerColor = WaslColors.WarmIvoryBackground,
                        unfocusedContainerColor = WaslColors.WarmIvoryBackground
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "٢. الرمز الشخصي (Avatar)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        text = WaslAvatarCatalog.getSpec(selectedAvatarId).arabicTitle,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = WaslColors.DeepOlivePrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    WaslAvatarCatalog.avatars.forEach { spec ->
                        WaslAvatarBadge(
                            avatarId = spec.id,
                            size = 58.dp,
                            isSelected = selectedAvatarId == spec.id,
                            onClick = { selectedAvatarId = spec.id }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                WaslSecondaryButton(
                    text = if (customPhotoUri != null) "تم اختيار صورة شخصية من المعرض ✓" else "أو اختر صورة شخصية من معرض الهاتف",
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "يُحفظ اسمك وصورتك محليًا على جهازك فقط، ولن يُطلبا منك مجددًا عند فتح التطبيق.",
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        WaslPrimaryButton(
            text = "متابعة إلى وَصْل",
            enabled = nickname.trim().length >= 2,
            onClick = {
                onCompleteOnboarding(nickname.trim(), selectedAvatarId, customPhotoUri)
            },
            modifier = Modifier.fillMaxWidth()
        )
    }
}
