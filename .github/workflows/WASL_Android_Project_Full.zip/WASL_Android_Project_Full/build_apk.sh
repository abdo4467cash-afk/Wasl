#!/usr/bin/env bash
set -e

echo "===================================================="
echo "  بناء تطبيق وَصْل | WASL — Local Chat Android APK"
echo "===================================================="

if command -v ./gradlew >/dev/null 2>&1 && [ -f "./gradle/wrapper/gradle-wrapper.jar" ]; then
    GRADLE_CMD="./gradlew"
elif command -v gradle >/dev/null 2>&1; then
    GRADLE_CMD="gradle"
else
    echo "⚠️ لم يتم العثور على أمر gradle في النظام. يرجى فتح المشروع في Android Studio أو تثبيت Gradle 8.6."
    exit 1
fi

echo "1. تشغيل اختبارات بروتوكول الشبكة والتأطير..."
$GRADLE_CMD testDebugUnitTest

echo "2. بناء ملف APK القابل للتثبيت (Debug APK)..."
$GRADLE_CMD assembleDebug

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    echo "✅ تم إنتاج ملف APK بنجاح في المسار:"
    echo "   $APK_PATH"
else
    echo "❌ تعذّر العثور على ملف APK الناتج."
    exit 1
fi
