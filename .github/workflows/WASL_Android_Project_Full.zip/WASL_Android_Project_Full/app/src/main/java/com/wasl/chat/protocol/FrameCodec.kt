package com.wasl.chat.protocol

import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.IOException
import java.nio.charset.StandardCharsets

/**
 * Packet types exchanged over real TCP Socket (Wi-Fi LAN) or BluetoothSocket (RFCOMM).
 */
enum class PacketType {
    HELLO,          // Initial handshake exchanging userId, nickname, avatarId
    CHAT_MESSAGE,   // Actual text message with unique UUID
    DELIVERY_ACK,   // Real technical receipt confirmation sent by the recipient device
    PING,           // Keep-alive check
    PONG,           // Keep-alive response
    DISCONNECT      // Graceful session close notice
}

data class WirePacket(
    val type: PacketType,
    val packetId: String,
    val sessionId: String,
    val senderId: String,
    val senderName: String,
    val senderAvatarId: Int,
    val payload: String,
    val timestamp: Long,
    val ackTargetMessageId: String? = null
)

/**
 * Provides reliable length-prefixed framing over stream sockets (TCP and RFCOMM)
 * so that partial reads or coalesced packets never corrupt or merge messages.
 *
 * Frame layout:
 * [4-byte Big-Endian signed integer: byte length N] + [N bytes of UTF-8 JSON]
 */
object FrameCodec {
    const val MAX_FRAME_BYTES = 64 * 1024 // 64 KB safety cap against malformed/hostile frames
    const val MAX_MESSAGE_CHARS = 4000    // Supports long editorial messages safely

    fun encodeToJsonBytes(packet: WirePacket): ByteArray {
        val sanitizedPayload = packet.payload.take(MAX_MESSAGE_CHARS)
        val json = JSONObject().apply {
            put("v", 1)
            put("type", packet.type.name)
            put("packetId", packet.packetId.take(64))
            put("sessionId", packet.sessionId.take(128))
            put("senderId", packet.senderId.take(64))
            put("senderName", packet.senderName.trim().take(40))
            put("senderAvatarId", packet.senderAvatarId.coerceIn(0, 15))
            put("payload", sanitizedPayload)
            put("timestamp", packet.timestamp)
            if (!packet.ackTargetMessageId.isNullOrBlank()) {
                put("ackTargetMessageId", packet.ackTargetMessageId.take(64))
            }
        }
        return json.toString().toByteArray(StandardCharsets.UTF_8)
    }

    fun decodeFromJsonBytes(bytes: ByteArray): WirePacket {
        if (bytes.isEmpty() || bytes.size > MAX_FRAME_BYTES) {
            throw IOException("Invalid frame size: ${bytes.size}")
        }
        val raw = String(bytes, StandardCharsets.UTF_8)
        val json = JSONObject(raw)
        val typeStr = json.optString("type", "")
        val type = try {
            PacketType.valueOf(typeStr)
        } catch (e: IllegalArgumentException) {
            throw IOException("Unsupported packet type: $typeStr")
        }

        val packetId = json.optString("packetId", "").trim()
        val senderId = json.optString("senderId", "").trim()
        if (packetId.isEmpty() || senderId.isEmpty()) {
            throw IOException("Malformed packet: missing mandatory identifiers")
        }

        return WirePacket(
            type = type,
            packetId = packetId,
            sessionId = json.optString("sessionId", "default"),
            senderId = senderId,
            senderName = json.optString("senderName", "مستخدم قريب").trim().ifEmpty { "مستخدم قريب" },
            senderAvatarId = json.optInt("senderAvatarId", 0).coerceIn(0, 15),
            payload = json.optString("payload", "").take(MAX_MESSAGE_CHARS),
            timestamp = json.optLong("timestamp", System.currentTimeMillis()),
            ackTargetMessageId = json.optString("ackTargetMessageId", "").ifEmpty { null }
        )
    }

    @Synchronized
    @Throws(IOException::class)
    fun writeFrame(out: DataOutputStream, packet: WirePacket) {
        val data = encodeToJsonBytes(packet)
        if (data.size > MAX_FRAME_BYTES) {
            throw IOException("Frame exceeds maximum allowed byte length (${data.size})")
        }
        out.writeInt(data.size)
        out.write(data)
        out.flush()
    }

    @Throws(IOException::class)
    fun readFrame(input: DataInputStream): WirePacket {
        val length: Int = try {
            input.readInt()
        } catch (eof: EOFException) {
            throw eof
        }
        if (length <= 0 || length > MAX_FRAME_BYTES) {
            throw IOException("Corrupt or rejected frame length: $length")
        }
        val buffer = ByteArray(length)
        input.readFully(buffer)
        return decodeFromJsonBytes(buffer)
    }
}
