package com.wasl.chat.data

import android.content.Context
import android.content.SharedPreferences
import com.wasl.chat.model.TransportType
import com.wasl.chat.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

/**
 * Persists the user's nickname, chosen avatar/photo URI, unique device peer ID,
 * and last preferred transport locally without requiring any cloud account.
 */
class UserPreferencesRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("wasl_user_prefs", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow<UserProfile?>(loadProfile())
    val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

    private val _selectedTransport = MutableStateFlow(loadPreferredTransport())
    val selectedTransport: StateFlow<TransportType> = _selectedTransport.asStateFlow()

    private fun loadProfile(): UserProfile? {
        val nickname = prefs.getString(KEY_NICKNAME, null)?.trim()
        if (nickname.isNullOrEmpty()) return null

        var userId = prefs.getString(KEY_USER_ID, null)
        if (userId.isNullOrEmpty()) {
            userId = "wasl_" + UUID.randomUUID().toString().replace("-", "").take(12)
            prefs.edit().putString(KEY_USER_ID, userId).apply()
        }

        val avatarId = prefs.getInt(KEY_AVATAR_ID, 0).coerceIn(0, 7)
        val customUri = prefs.getString(KEY_CUSTOM_AVATAR_URI, null)
        return UserProfile(
            userId = userId,
            nickname = nickname,
            avatarId = avatarId,
            customAvatarUri = customUri
        )
    }

    private fun loadPreferredTransport(): TransportType {
        val raw = prefs.getString(KEY_TRANSPORT, TransportType.WIFI_LAN.name) ?: TransportType.WIFI_LAN.name
        return runCatching { TransportType.valueOf(raw) }.getOrDefault(TransportType.WIFI_LAN)
    }

    fun saveUserProfile(nickname: String, avatarId: Int, customAvatarUri: String?) {
        val cleanName = nickname.trim().take(36)
        if (cleanName.isEmpty()) return

        val existingId = prefs.getString(KEY_USER_ID, null)
            ?: ("wasl_" + UUID.randomUUID().toString().replace("-", "").take(12))

        prefs.edit()
            .putString(KEY_USER_ID, existingId)
            .putString(KEY_NICKNAME, cleanName)
            .putInt(KEY_AVATAR_ID, avatarId.coerceIn(0, 7))
            .putString(KEY_CUSTOM_AVATAR_URI, customAvatarUri)
            .apply()

        _userProfile.value = UserProfile(
            userId = existingId,
            nickname = cleanName,
            avatarId = avatarId.coerceIn(0, 7),
            customAvatarUri = customAvatarUri
        )
    }

    fun setPreferredTransport(transportType: TransportType) {
        prefs.edit().putString(KEY_TRANSPORT, transportType.name).apply()
        _selectedTransport.value = transportType
    }

    companion object {
        private const val KEY_USER_ID = "user_id"
        private const val KEY_NICKNAME = "nickname"
        private const val KEY_AVATAR_ID = "avatar_id"
        private const val KEY_CUSTOM_AVATAR_URI = "custom_avatar_uri"
        private const val KEY_TRANSPORT = "preferred_transport"
    }
}
